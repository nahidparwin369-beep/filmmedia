import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './lib/theme';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';
import Home from './pages/Home';
import Search from './pages/Search';
import Detail from './pages/Detail';
import Categories from './pages/Categories';
import Watchlist from './pages/Watchlist';
import ComingSoon from './pages/ComingSoon';
import ActorProfile from './pages/ActorProfile';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <ScrollToTop />
        <div className="flex min-h-screen flex-col bg-zinc-950 text-zinc-100">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/coming-soon" element={<ComingSoon />} />
              <Route path="/watchlist" element={<Watchlist />} />
              <Route path="/movie/:id" element={<Detail type="movie" />} />
              <Route path="/tv/:id" element={<Detail type="tv" />} />
              <Route path="/actor/:id" element={<ActorProfile />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </ThemeProvider>
  );
}
