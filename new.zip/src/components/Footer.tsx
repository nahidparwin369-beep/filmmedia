import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';
import { WebsiteRating } from './WebsiteRating';

export function Footer() {
  return (
    <footer className="mt-12 border-t border-white/10 bg-zinc-950 px-4 py-10 sm:px-8">
      <div className="mx-auto max-w-[1600px]">
        <div className="flex flex-col gap-8 md:flex-row md:justify-between">
          {/* Logo + tagline */}
          <div className="max-w-sm">
            <Link to="/" className="flex items-center gap-2">
              <svg
                className="h-7 w-7 flex-shrink-0 text-red-600"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <circle cx="12" cy="12" r="10" />
                <circle cx="12" cy="7" r="1.5" fill="currentColor" stroke="none" />
                <circle cx="17" cy="12" r="1.5" fill="currentColor" stroke="none" />
                <circle cx="12" cy="17" r="1.5" fill="currentColor" stroke="none" />
                <circle cx="7" cy="12" r="1.5" fill="currentColor" stroke="none" />
                <circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none" />
              </svg>
              <span className="brand-text text-xl sm:text-2xl">
                <span className="brand-film">Film</span>
                <span className="brand-media"> Media</span>
              </span>
            </Link>
            <p className="mt-3 text-sm text-zinc-500">
              Film Media — Your Ultimate Movie Guide. Discover movies and web series
              from around the world, powered by TMDB.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-3 text-xs font-bold uppercase tracking-wide text-zinc-400">
              Quick Links
            </h4>
            <ul className="space-y-2 text-sm text-zinc-500">
              <li><Link to="/" className="transition hover:text-white">Home</Link></li>
              <li><Link to="/categories" className="transition hover:text-white">Movies</Link></li>
              <li><Link to="/categories?type=tv" className="transition hover:text-white">Web Series</Link></li>
              <li><Link to="/categories" className="transition hover:text-white">Categories</Link></li>
              <li><Link to="/coming-soon" className="transition hover:text-white">Coming Soon</Link></li>
            </ul>
          </div>

          {/* Genres */}
          <div>
            <h4 className="mb-3 text-xs font-bold uppercase tracking-wide text-zinc-400">
              Genres
            </h4>
            <ul className="space-y-2 text-sm text-zinc-500">
              <li><Link to="/categories?genre=28" className="transition hover:text-white">Action</Link></li>
              <li><Link to="/categories?genre=27" className="transition hover:text-white">Horror</Link></li>
              <li><Link to="/categories?genre=35" className="transition hover:text-white">Comedy</Link></li>
              <li><Link to="/categories?genre=10749" className="transition hover:text-white">Romance</Link></li>
              <li><Link to="/categories?genre=53" className="transition hover:text-white">Thriller</Link></li>
              <li><Link to="/categories?genre=878" className="transition hover:text-white">Sci-Fi</Link></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="mb-3 text-xs font-bold uppercase tracking-wide text-zinc-400">
              Connect
            </h4>
            <div className="flex gap-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-blue-600 hover:text-white"
                aria-label="Facebook"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-pink-600 hover:text-white"
                aria-label="Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-blue-500 hover:text-white"
                aria-label="Twitter"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-red-600 hover:text-white"
                aria-label="YouTube"
              >
                <Youtube className="h-4 w-4" />
              </a>
            </div>
            <p className="mt-3 text-xs text-zinc-600">
              Follow us for the latest movie updates!
            </p>
          </div>
        </div>

        {/* Website Rating Section */}
        <WebsiteRating />

        {/* Bottom bar */}
        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-zinc-600 sm:flex-row">
          <p>© 2026 Film Media. All Rights Reserved.</p>
          <p>
            Data & images courtesy of{' '}
            <span className="text-zinc-400">The Movie Database (TMDB)</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
