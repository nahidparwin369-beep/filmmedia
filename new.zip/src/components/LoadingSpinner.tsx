import { Film } from 'lucide-react';

export function LoadingSpinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizeClass =
    size === 'sm' ? 'h-6 w-6' : size === 'lg' ? 'h-12 w-12' : 'h-8 w-8';
  return (
    <div className="flex items-center justify-center">
      <div className="relative">
        <div
          className={`${sizeClass} animate-spin rounded-full border-2 border-zinc-800 border-t-red-600`}
        />
        <Film className="absolute left-1/2 top-1/2 h-1/2 w-1/2 -translate-x-1/2 -translate-y-1/2 text-red-600/40" />
      </div>
    </div>
  );
}

/** Full-screen loading spinner with fade-in content wrapper */
export function PageLoader() {
  return (
    <div className="flex min-h-[60vh] w-full items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="h-14 w-14 animate-spin rounded-full border-2 border-zinc-800 border-t-red-600" />
          <Film className="absolute left-1/2 top-1/2 h-7 w-7 -translate-x-1/2 -translate-y-1/2 text-red-600/40" />
        </div>
        <p className="animate-pulse text-sm text-zinc-500">Loading...</p>
      </div>
    </div>
  );
}
