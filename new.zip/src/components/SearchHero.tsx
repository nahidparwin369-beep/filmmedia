import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, TrendingUp, Star, Film, Tv, Loader2, X } from 'lucide-react';
import { tmdb, img, getTitle, getYear, getMediaType, type Media } from '../lib/tmdb';

type SearchMode = 'movie' | 'tv' | 'both';

const POPULAR_TAGS = [
  { label: '#Trending', query: 'trending', to: '/search?q=trending' },
  { label: '#Action', genre: 28 },
  { label: '#Horror', genre: 27 },
  { label: '#Comedy', genre: 35 },
  { label: '#Thriller', genre: 53 },
  { label: '#Romance', genre: 10749 },
  { label: '#Sci-Fi', genre: 878 },
];

export function SearchHero({ trending }: { trending: Media[] }) {
  const [query, setQuery] = useState('');
  const [mode, setMode] = useState<SearchMode>('both');
  const [results, setResults] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Debounced live search
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (!query.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const data = await tmdb.search(query, 1);
        let filtered = data.results.filter(
          (m) =>
            (m.media_type === 'movie' || m.media_type === 'tv') &&
            m.poster_path
        );
        if (mode === 'movie') filtered = filtered.filter((m) => m.media_type === 'movie');
        if (mode === 'tv') filtered = filtered.filter((m) => m.media_type === 'tv');
        setResults(filtered.slice(0, 8));
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 350);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query, mode]);

  // Close results on outside click
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setShowResults(false);
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  const trendingSuggestions = trending.filter((m) => m.poster_path).slice(0, 8);
  const displayResults = query.trim() ? results : trendingSuggestions;
  const showDropdown = showResults && (displayResults.length > 0 || loading);

  return (
    <section className="relative overflow-hidden">
      {/* Cinematic gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-900 via-zinc-950 to-zinc-950" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(220,38,38,0.15),transparent_60%)]" />
      {/* Decorative film grain dots */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
        backgroundSize: '24px 24px',
      }} />

      <div className="relative z-10 mx-auto max-w-4xl px-4 pb-10 pt-24 text-center sm:pt-28 sm:pb-14">
        {/* Heading */}
        <h1 className="text-3xl font-black leading-tight tracking-tight text-white drop-shadow-lg sm:text-5xl md:text-6xl">
          Find Your Next{' '}
          <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">
            Favourite Movie
          </span>
        </h1>
        <p className="mt-3 text-sm text-zinc-400 sm:text-lg">
          Search from millions of movies &amp; web series
        </p>

        {/* Search bar */}
        <div ref={containerRef} className="relative mx-auto mt-7 max-w-2xl">
          <form onSubmit={handleSubmit}>
            <div className="flex items-center gap-2 rounded-2xl bg-zinc-900/90 p-2 shadow-2xl ring-1 ring-white/10 backdrop-blur transition focus-within:ring-2 focus-within:ring-red-600">
              <div className="grid flex-1 items-center gap-2 sm:flex">
                <Search className="ml-2 hidden h-5 w-5 flex-shrink-0 text-zinc-500 sm:block" />
                <input
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setShowResults(true);
                  }}
                  onFocus={() => setShowResults(true)}
                  placeholder="Search movies, series, actors..."
                  className="w-full bg-transparent px-3 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none sm:text-base"
                  autoComplete="off"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => {
                      setQuery('');
                      setResults([]);
                    }}
                    className="grid h-7 w-7 flex-shrink-0 place-items-center rounded-full text-zinc-500 transition hover:bg-zinc-800 hover:text-white"
                    aria-label="Clear search"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <button
                type="submit"
                className="flex flex-shrink-0 items-center gap-2 rounded-xl bg-red-600 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
              >
                <Search className="h-4 w-4" />
                <span className="hidden sm:inline">Search</span>
              </button>
            </div>
          </form>

          {/* Live results dropdown */}
          {showDropdown && (
            <div className="absolute left-0 right-0 top-full z-50 mt-2 max-h-[60vh] overflow-y-auto rounded-2xl border border-white/10 bg-zinc-900/98 p-2 shadow-2xl backdrop-blur-xl scrollbar-none animate-scale-in">
              {loading && (
                <div className="flex items-center justify-center gap-2 py-6">
                  <Loader2 className="h-5 w-5 animate-spin text-red-600" />
                  <span className="text-sm text-zinc-400">Searching...</span>
                </div>
              )}

              {!loading && !query.trim() && (
                <p className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  <TrendingUp className="h-3.5 w-3.5" /> Trending Now
                </p>
              )}

              {!loading && query.trim() && displayResults.length === 0 && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Search className="h-8 w-8 text-zinc-700" />
                  <p className="mt-2 text-sm text-zinc-400">No results found</p>
                  <p className="text-xs text-zinc-600">Try a different search term</p>
                </div>
              )}

              {!loading && displayResults.length > 0 && (
                <div className="space-y-1">
                  {displayResults.map((m) => {
                    const type = getMediaType(m);
                    return (
                      <Link
                        key={`${m.id}-${m.media_type}`}
                        to={`/${type}/${m.id}`}
                        onClick={() => setShowResults(false)}
                        className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-zinc-800"
                      >
                        {/* Poster */}
                        <div className="h-16 w-11 flex-shrink-0 overflow-hidden rounded-md bg-zinc-800">
                          {m.poster_path ? (
                            <img
                              src={img(m.poster_path, 'w92')}
                              alt={getTitle(m)}
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="grid h-full w-full place-items-center">
                              <Film className="h-4 w-4 text-zinc-700" />
                            </div>
                          )}
                        </div>
                        {/* Info */}
                        <div className="min-w-0 flex-1 text-left">
                          <p className="truncate text-sm font-semibold text-white">
                            {getTitle(m)}
                          </p>
                          <div className="mt-0.5 flex items-center gap-2 text-xs text-zinc-500">
                            <span className="flex items-center gap-0.5">
                              {type === 'tv' ? (
                                <Tv className="h-3 w-3" />
                              ) : (
                                <Film className="h-3 w-3" />
                              )}
                              {type === 'tv' ? 'Series' : 'Movie'}
                            </span>
                            <span>•</span>
                            <span>{getYear(m)}</span>
                            {m.vote_average > 0 && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-0.5 font-medium text-yellow-500">
                                  <Star className="h-3 w-3 fill-yellow-500" />
                                  {m.vote_average.toFixed(1)}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                  {query.trim() && (
                    <button
                      onClick={() => {
                        setShowResults(false);
                        navigate(`/search?q=${encodeURIComponent(query.trim())}`);
                      }}
                      className="w-full rounded-xl bg-zinc-800/60 py-2.5 text-center text-xs font-semibold text-red-500 transition hover:bg-zinc-800 hover:text-red-400"
                    >
                      View all results for "{query}" →
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Toggle buttons */}
        <div className="mt-5 flex items-center justify-center gap-2">
          {(
            [
              { value: 'movie', label: 'Movies' },
              { value: 'tv', label: 'Web Series' },
              { value: 'both', label: 'Both' },
            ] as { value: SearchMode; label: string }[]
          ).map((opt) => (
            <button
              key={opt.value}
              onClick={() => setMode(opt.value)}
              className={`rounded-full px-4 py-1.5 text-xs font-bold transition sm:text-sm ${
                mode === opt.value
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                  : 'bg-zinc-800/80 text-zinc-400 ring-1 ring-white/10 hover:bg-zinc-700 hover:text-white'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Popular tags */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          {POPULAR_TAGS.map((tag) => {
            const isTrending = 'query' in tag;
            return (
              <Link
                key={tag.label}
                to={isTrending ? tag.to! : `/categories?genre=${tag.genre}`}
                className="rounded-full bg-zinc-800/60 px-3 py-1 text-xs font-medium text-zinc-400 ring-1 ring-white/5 transition hover:bg-red-600 hover:text-white"
              >
                {tag.label}
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
