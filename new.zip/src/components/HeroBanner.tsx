import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, Info, Star, Plus, Check } from 'lucide-react';
import { img, getTitle, getYear, getMediaType, type Media } from '../lib/tmdb';
import { useWatchlist } from '../lib/watchlist';

export function HeroBanner({ items }: { items: Media[] }) {
  const [index, setIndex] = useState(0);
  const { isInList, toggle } = useWatchlist();

  const featured = items.filter((m) => m.backdrop_path).slice(0, 5);
  const media = featured[index];

  useEffect(() => {
    if (featured.length <= 1) return;
    const t = setInterval(() => {
      setIndex((i) => (i + 1) % featured.length);
    }, 8000);
    return () => clearInterval(t);
  }, [featured.length]);

  if (!media) return null;
  const type = getMediaType(media);
  const inList = isInList(media.id);

  return (
    <section className="relative h-[60vh] sm:h-[80vh] w-full overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0">
        {featured.map((m, i) => (
          <img
            key={m.id}
            src={img(m.backdrop_path, 'original')}
            alt={getTitle(m)}
            className={`h-full w-full object-cover transition-opacity duration-1000 ${
              i === index ? 'opacity-100' : 'opacity-0'
            }`}
          />
        ))}
      </div>

      {/* Gradients */}
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-zinc-950/90 via-zinc-950/30 to-transparent" />

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col justify-end px-4 pb-10 sm:px-8 sm:pb-16 max-w-3xl">
        <span className="mb-2 inline-flex w-fit items-center gap-1.5 rounded-full bg-red-600/90 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
          🔥 Trending Now
        </span>
        <h1 className="text-3xl font-extrabold leading-tight text-white drop-shadow-lg sm:text-5xl md:text-6xl">
          {getTitle(media)}
        </h1>

        <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-zinc-300">
          <span className="flex items-center gap-1 font-semibold text-yellow-400">
            <Star className="h-4 w-4 fill-yellow-400" />
            {media.vote_average?.toFixed(1)}
          </span>
          <span className="text-zinc-400">•</span>
          <span>{getYear(media)}</span>
          <span className="text-zinc-400">•</span>
          <span className="uppercase">{type === 'tv' ? 'Series' : 'Movie'}</span>
          {media.original_language && (
            <>
              <span className="text-zinc-400">•</span>
              <span className="uppercase">{media.original_language}</span>
            </>
          )}
        </div>

        <p className="mt-3 line-clamp-2 max-w-xl text-sm text-zinc-300 sm:text-base">
          {media.overview}
        </p>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Link
            to={`/${type}/${media.id}`}
            className="flex items-center gap-2 rounded-md bg-white px-5 py-2.5 text-sm font-bold text-black transition hover:bg-white/80"
          >
            <Play className="h-4 w-4 fill-black" /> View Details
          </Link>
          <button
            onClick={() => toggle(media)}
            className={`flex items-center gap-2 rounded-md px-5 py-2.5 text-sm font-bold transition ${
              inList
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-zinc-700/80 text-white hover:bg-zinc-600'
            }`}
          >
            {inList ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {inList ? 'Added' : 'My List'}
          </button>
        </div>

        {/* Dots */}
        {featured.length > 1 && (
          <div className="mt-6 flex gap-1.5">
            {featured.map((_, i) => (
              <button
                key={i}
                onClick={() => setIndex(i)}
                className={`h-1 rounded-full transition-all ${
                  i === index ? 'w-8 bg-red-600' : 'w-4 bg-zinc-600 hover:bg-zinc-400'
                }`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
