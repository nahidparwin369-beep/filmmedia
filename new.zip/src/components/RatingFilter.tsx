import { Star } from 'lucide-react';

interface RatingFilterProps {
  value: number;
  onChange: (rating: number) => void;
}

const OPTIONS = [
  { value: 0, label: 'All' },
  { value: 6, label: '6+' },
  { value: 7, label: '7+' },
  { value: 8, label: '8+' },
  { value: 9, label: '9+' },
];

export function RatingFilter({ value, onChange }: RatingFilterProps) {
  return (
    <div className="flex items-center gap-2">
      <span className="flex items-center gap-1 text-xs font-semibold uppercase text-zinc-500">
        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" /> Rating
      </span>
      <div className="flex gap-1.5">
        {OPTIONS.map((opt) => (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            className={`rounded-full px-3 py-1 text-xs font-medium transition ${
              value === opt.value
                ? 'bg-red-600 text-white'
                : 'bg-zinc-800/60 text-zinc-400 hover:bg-zinc-700 hover:text-white'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}
