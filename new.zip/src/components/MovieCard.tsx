import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, Plus, Check, Play, Share2, Film } from 'lucide-react';
import { img, getTitle, getYear, getMediaType, type Media } from '../lib/tmdb';
import { useWatchlist } from '../lib/watchlist';
import { TrailerModal } from './TrailerModal';
import { ShareModal } from './ShareModal';
import { getTopBadge } from '../lib/badges';

interface MovieCardProps {
  media: Media;
  index?: number;
  fullWidth?: boolean;
}

export function MovieCard({ media, index = 0, fullWidth = false }: MovieCardProps) {
  const { isInList, toggle } = useWatchlist();
  const [trailerMedia, setTrailerMedia] = useState<Media | null>(null);
  const [shareMedia, setShareMedia] = useState<Media | null>(null);
  const [imgError, setImgError] = useState(false);
  const type = getMediaType(media);
  const inList = isInList(media.id);
  const poster = img(media.poster_path, 'w342');
  const topBadge = getTopBadge(media);

  const widthClass = fullWidth ? 'w-full' : 'w-[140px] sm:w-[170px] md:w-[180px]';

  return (
    <>
      <div
        className={`group relative ${widthClass} flex-shrink-0 transition-transform duration-300 hover:scale-105 hover:z-20`}
        style={{ animationDelay: `${index * 40}ms` }}
      >
        <Link to={`/${type}/${media.id}`} className="block">
          <div className="relative aspect-[2/3] overflow-hidden rounded-lg bg-zinc-800 shadow-lg">
            {poster && !imgError ? (
              <img
                src={poster}
                alt={getTitle(media)}
                loading="lazy"
                className="h-full w-full object-cover transition-opacity duration-300 group-hover:opacity-90"
                onError={() => setImgError(true)}
              />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-zinc-800 p-2 text-center">
                <Film className="h-8 w-8 text-zinc-600" />
                <span className="text-[11px] font-medium text-zinc-500 line-clamp-3">
                  {getTitle(media)}
                </span>
              </div>
            )}

            {/* Status badge (NEW / HOT / TRENDING) */}
            {topBadge && (
              <div
                className={`absolute top-1.5 left-1.5 z-10 rounded ${topBadge.bg} px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide ${topBadge.color} shadow-lg`}
              >
                {topBadge.label}
              </div>
            )}

            {/* Rating badge */}
            <div className="absolute top-1.5 right-1.5 flex items-center gap-0.5 rounded-md bg-black/70 backdrop-blur px-1.5 py-0.5">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
              <span className="text-[10px] font-semibold text-white">
                {media.vote_average ? media.vote_average.toFixed(1) : '—'}
              </span>
            </div>

            {/* Type badge */}
            <div className="absolute top-8 right-1.5 rounded bg-zinc-900/80 backdrop-blur px-1.5 py-0.5 text-[8px] font-bold uppercase text-zinc-300">
              {type === 'tv' ? 'Series' : 'Movie'}
            </div>

            {/* Hover overlay */}
            <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/90 via-black/30 to-transparent p-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              <p className="line-clamp-2 text-[11px] text-zinc-200">
                {media.overview || 'No description available.'}
              </p>
            </div>

            {/* Trailer button - appears on hover */}
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setTrailerMedia(media);
              }}
              className="absolute left-1.5 bottom-1.5 grid h-7 w-7 place-items-center rounded-full bg-white/90 text-black opacity-0 backdrop-blur transition-all hover:bg-white group-hover:opacity-100"
              title="Watch trailer"
            >
              <Play className="h-3.5 w-3.5 fill-black" />
            </button>

            {/* Share button - appears on hover */}
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setShareMedia(media);
              }}
              className="absolute bottom-9 right-1.5 grid h-7 w-7 place-items-center rounded-full bg-black/70 text-white opacity-0 backdrop-blur transition-all hover:bg-blue-600 group-hover:opacity-100"
              title="Share"
            >
              <Share2 className="h-3.5 w-3.5" />
            </button>

            {/* Watchlist button */}
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggle(media);
              }}
              className={`absolute bottom-1.5 right-1.5 grid h-7 w-7 place-items-center rounded-full backdrop-blur transition-all ${
                inList
                  ? 'bg-green-500 text-white'
                  : 'bg-black/70 text-white hover:bg-red-600'
              }`}
              title={inList ? 'Remove from watchlist' : 'Add to watchlist'}
            >
              {inList ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
            </button>
          </div>
        </Link>

        <div className="mt-1.5">
          <h3 className="truncate text-xs font-medium text-zinc-200 group-hover:text-white">
            {getTitle(media)}
          </h3>
          <p className="text-[10px] text-zinc-500">{getYear(media)}</p>
        </div>
      </div>

      <TrailerModal media={trailerMedia} onClose={() => setTrailerMedia(null)} />
      <ShareModal media={shareMedia} type={type} onClose={() => setShareMedia(null)} />
    </>
  );
}
