import { useState } from 'react';
import { Star, Trash2, MessageSquare, Send } from 'lucide-react';
import { useReviews } from '../lib/reviews';

interface ReviewsSectionProps {
  mediaId: number;
  mediaTitle: string;
}

export function ReviewsSection({ mediaId, mediaTitle }: ReviewsSectionProps) {
  const { reviews, addReview, deleteReview } = useReviews(mediaId);
  const [name, setName] = useState('');
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  const [hoverRating, setHoverRating] = useState(0);
  const [showForm, setShowForm] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    addReview(name, rating, text);
    setName('');
    setRating(5);
    setText('');
    setShowForm(false);
  };

  return (
    <div className="mt-10">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-bold text-white">
          <MessageSquare className="h-5 w-5 text-red-600" />
          User Reviews
          {reviews.length > 0 && (
            <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-xs font-medium text-zinc-400">
              {reviews.length}
            </span>
          )}
        </h2>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="rounded-full bg-red-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-red-700"
        >
          {showForm ? 'Cancel' : 'Write a Review'}
        </button>
      </div>

      {/* Review form */}
      {showForm && (
        <form
          onSubmit={submit}
          className="mb-6 animate-slide-up rounded-xl bg-zinc-900 p-4 ring-1 ring-white/10"
        >
          <div className="mb-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name (optional)"
              className="rounded-lg bg-zinc-800 px-3 py-2 text-sm text-white placeholder:text-zinc-500 ring-1 ring-white/10 focus:outline-none focus:ring-red-600"
            />
            <div className="flex items-center gap-1">
              <span className="mr-2 text-xs text-zinc-500">Your rating:</span>
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onMouseEnter={() => setHoverRating(s)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(s)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`h-6 w-6 transition-colors ${
                      s <= (hoverRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-zinc-600'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={`Share your thoughts on ${mediaTitle}...`}
            rows={3}
            className="mb-3 w-full resize-none rounded-lg bg-zinc-800 px-3 py-2 text-sm text-white placeholder:text-zinc-500 ring-1 ring-white/10 focus:outline-none focus:ring-red-600"
          />
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={!text.trim()}
              className="flex items-center gap-2 rounded-full bg-red-600 px-5 py-2 text-sm font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Send className="h-4 w-4" /> Post Review
            </button>
          </div>
        </form>
      )}

      {/* Reviews list */}
      {reviews.length === 0 ? (
        <div className="rounded-xl bg-zinc-900 p-8 text-center ring-1 ring-white/5">
          <MessageSquare className="mx-auto h-10 w-10 text-zinc-700" />
          <p className="mt-3 text-sm font-medium text-zinc-400">No reviews yet</p>
          <p className="mt-1 text-xs text-zinc-600">Be the first to review {mediaTitle}!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reviews.map((r) => (
            <div
              key={r.id}
              className="animate-fade-in rounded-xl bg-zinc-900 p-4 ring-1 ring-white/5"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-red-600 to-red-800 text-sm font-bold text-white">
                    {r.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{r.name}</p>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`h-3 w-3 ${
                              s <= r.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-zinc-700'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[10px] text-zinc-500">
                        {new Date(r.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => deleteReview(r.id)}
                  className="grid h-7 w-7 place-items-center rounded-full text-zinc-600 transition hover:bg-red-600/20 hover:text-red-500"
                  title="Delete review"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-zinc-300">{r.text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
