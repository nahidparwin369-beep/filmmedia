import { useState, useEffect } from 'react';
import { X, Copy, Check, MessageCircle, Instagram, Share2 } from 'lucide-react';
import { img, getTitle, type Media } from '../lib/tmdb';

interface ShareModalProps {
  media: Media | null;
  type: 'movie' | 'tv';
  onClose: () => void;
}

export function ShareModal({ media, type, onClose }: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!media) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [media, onClose]);

  if (!media) return null;

  const title = getTitle(media);
  const shareUrl = `${window.location.origin}/${type}/${media.id}`;
  const shareText = `Check out "${title}" on Film Media! ${shareUrl}`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
    }
  };

  const shareWhatsApp = () => {
    window.open(
      `https://wa.me/?text=${encodeURIComponent(shareText)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const shareTwitter = () => {
    window.open(
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Check out "${title}" on Film Media!`)}&url=${encodeURIComponent(shareUrl)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const shareFacebook = () => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const poster = img(media.poster_path, 'w500');

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md animate-scale-in overflow-hidden rounded-2xl bg-zinc-900 shadow-2xl ring-1 ring-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
          <h3 className="flex items-center gap-2 text-sm font-bold text-white">
            <Share2 className="h-4 w-4 text-red-600" /> Share
          </h3>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-red-600 hover:text-white"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Instagram-style share card preview */}
        <div className="p-5">
          <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900">
            {poster ? (
              <div className="relative aspect-[16/9]">
                <img
                  src={poster}
                  alt={title}
                  className="h-full w-full object-cover opacity-60"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-t from-black/80 to-transparent p-4 text-center">
                  <p className="text-lg font-extrabold text-white drop-shadow-lg">
                    {title}
                  </p>
                  {media.vote_average > 0 && (
                    <p className="mt-1 text-sm text-yellow-400">
                      ⭐ {media.vote_average.toFixed(1)}/10
                    </p>
                  )}
                  <p className="mt-2 text-[10px] text-zinc-400">{shareUrl}</p>
                </div>
              </div>
            ) : (
              <div className="flex aspect-[16/9] flex-col items-center justify-center p-4 text-center">
                <p className="text-lg font-extrabold text-white">{title}</p>
                <p className="mt-2 text-[10px] text-zinc-400">{shareUrl}</p>
              </div>
            )}
          </div>

          {/* Share buttons */}
          <div className="mt-5 grid grid-cols-4 gap-3">
            {/* WhatsApp */}
            <button
              onClick={shareWhatsApp}
              className="flex flex-col items-center gap-1.5 rounded-xl bg-zinc-800 p-3 transition hover:bg-green-600"
            >
              <MessageCircle className="h-5 w-5 text-green-500 transition group-hover:text-white" />
              <span className="text-[10px] font-medium text-zinc-400">WhatsApp</span>
            </button>

            {/* Twitter/X */}
            <button
              onClick={shareTwitter}
              className="flex flex-col items-center gap-1.5 rounded-xl bg-zinc-800 p-3 transition hover:bg-blue-600"
            >
              <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
              </svg>
              <span className="text-[10px] font-medium text-zinc-400">Twitter</span>
            </button>

            {/* Facebook */}
            <button
              onClick={shareFacebook}
              className="flex flex-col items-center gap-1.5 rounded-xl bg-zinc-800 p-3 transition hover:bg-blue-700"
            >
              <svg className="h-5 w-5 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              <span className="text-[10px] font-medium text-zinc-400">Facebook</span>
            </button>

            {/* Copy link */}
            <button
              onClick={copyLink}
              className="flex flex-col items-center gap-1.5 rounded-xl bg-zinc-800 p-3 transition hover:bg-red-600"
            >
              {copied ? (
                <Check className="h-5 w-5 text-green-500" />
              ) : (
                <Copy className="h-5 w-5 text-zinc-400" />
              )}
              <span className="text-[10px] font-medium text-zinc-400">
                {copied ? 'Copied!' : 'Copy Link'}
              </span>
            </button>
          </div>

          {/* Instagram note */}
          <div className="mt-4 flex items-center gap-2 rounded-lg bg-zinc-800/50 p-3">
            <Instagram className="h-4 w-4 flex-shrink-0 text-pink-500" />
            <p className="text-[11px] text-zinc-400">
              Screenshot the card above to share on Instagram Stories!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
