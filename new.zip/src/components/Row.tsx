import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MovieCard } from './MovieCard';
import { CardSkeleton } from './Skeleton';
import type { Media } from '../lib/tmdb';

export function Row({
  title,
  items,
  loading,
  accent,
}: {
  title: string;
  items: Media[];
  loading?: boolean;
  accent?: string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = scrollRef.current.clientWidth * 0.8;
    scrollRef.current.scrollBy({
      left: dir === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  return (
    <section className="group/row relative py-4">
      <div className="flex items-center gap-2 px-4 sm:px-8 mb-2">
        {accent && <span className="text-lg">{accent}</span>}
        <h2 className="text-base sm:text-xl font-bold text-white">
          {title}
        </h2>
        <span className="ml-1 h-1 w-1 rounded-full bg-red-600" />
      </div>

      <div className="relative">
        {/* Left button */}
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-0 z-30 hidden h-full w-10 items-center justify-center bg-gradient-to-r from-black/80 to-transparent opacity-0 transition-opacity group-hover/row:opacity-100 sm:flex"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-8 w-8 text-white" />
        </button>

        <div
          ref={scrollRef}
          className="flex gap-3 overflow-x-auto scroll-smooth px-4 sm:px-8 pb-2 scrollbar-none"
          style={{ scrollbarWidth: 'none' }}
        >
          {loading
            ? Array.from({ length: 8 }).map((_, i) => (
                <CardSkeleton key={i} />
              ))
            : items.map((m, i) => (
                <MovieCard key={`${m.id}-${i}`} media={m} index={i} />
              ))}
        </div>

        {/* Right button */}
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-0 z-30 hidden h-full w-10 items-center justify-center bg-gradient-to-l from-black/80 to-transparent opacity-0 transition-opacity group-hover/row:opacity-100 sm:flex"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-8 w-8 text-white" />
        </button>
      </div>
    </section>
  );
}
