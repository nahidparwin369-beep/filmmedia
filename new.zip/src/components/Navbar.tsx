import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Search, Bookmark, Menu, X, Sun, Moon, Calendar } from 'lucide-react';
import { useWatchlist } from '../lib/watchlist';
import { useTheme } from '../lib/theme';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [query, setQuery] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const { count } = useWatchlist();
  const { theme, toggle } = useTheme();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
      setMobileOpen(false);
    }
  };

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/categories', label: 'Categories' },
    { to: '/categories?type=tv', label: 'Web Series' },
    { to: '/coming-soon', label: 'Coming Soon' },
    { to: '/watchlist', label: 'My List' },
  ];

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? 'bg-zinc-950/95 backdrop-blur-md shadow-lg shadow-black/50'
          : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-[1600px] items-center gap-4 px-4 py-3 sm:px-8">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 flex-shrink-0">
          <svg
            className="h-7 w-7 flex-shrink-0 text-red-600"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <circle cx="12" cy="12" r="10" />
            <circle cx="12" cy="7" r="1.5" fill="currentColor" stroke="none" />
            <circle cx="17" cy="12" r="1.5" fill="currentColor" stroke="none" />
            <circle cx="12" cy="17" r="1.5" fill="currentColor" stroke="none" />
            <circle cx="7" cy="12" r="1.5" fill="currentColor" stroke="none" />
            <circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none" />
          </svg>
          <span className="brand-text text-xl sm:text-2xl">
            <span className="brand-film">Film</span>
            <span className="brand-media"> Media</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((l) => {
            const isActive =
              l.to === '/'
                ? location.pathname === '/'
                : location.pathname.startsWith(l.to.split('?')[0]);
            return (
              <Link
                key={l.to + l.label}
                to={l.to}
                className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                  isActive ? 'text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </div>

        {/* Search */}
        <form onSubmit={submit} className="ml-auto hidden sm:flex items-center">
          <div className="flex items-center gap-2 rounded-full bg-zinc-800/80 px-3 py-1.5 ring-1 ring-white/10 focus-within:ring-red-600 transition">
            <Search className="h-4 w-4 text-zinc-400" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search movies, series..."
              className="w-28 bg-transparent text-sm text-white placeholder:text-zinc-500 focus:outline-none md:w-44"
            />
          </div>
        </form>

        {/* Theme toggle */}
        <button
          onClick={toggle}
          className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800/80 text-white transition-colors hover:bg-zinc-700"
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? (
            <Sun className="h-4 w-4 text-yellow-400" />
          ) : (
            <Moon className="h-4 w-4 text-blue-400" />
          )}
        </button>

        {/* Watchlist icon */}
        <Link
          to="/watchlist"
          className="relative grid h-9 w-9 place-items-center rounded-full bg-zinc-800/80 text-white hover:bg-red-600 transition-colors"
          title="Watchlist"
        >
          <Bookmark className="h-4 w-4" />
          {count > 0 && (
            <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-red-600 px-1 text-[9px] font-bold text-white">
              {count}
            </span>
          )}
        </Link>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setMobileOpen((v) => !v)}
          className="grid h-9 w-9 place-items-center rounded-full bg-zinc-800/80 text-white lg:hidden"
          aria-label="Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-white/10 bg-zinc-950/98 px-4 py-4 lg:hidden">
          <form onSubmit={submit} className="mb-3">
            <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-3 py-2">
              <Search className="h-4 w-4 text-zinc-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search movies, series..."
                className="w-full bg-transparent text-sm text-white placeholder:text-zinc-500 focus:outline-none"
              />
            </div>
          </form>
          <div className="flex flex-col gap-1">
            {navLinks.map((l) => (
              <Link
                key={l.to + l.label}
                to={l.to}
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-zinc-300 hover:bg-zinc-800 hover:text-white"
              >
                {l.label === 'Coming Soon' && <Calendar className="h-4 w-4 text-red-600" />}
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
