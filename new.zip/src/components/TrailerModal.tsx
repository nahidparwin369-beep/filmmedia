import { useState, useEffect } from 'react';
import { X, Loader2 } from 'lucide-react';
import { tmdb, getTitle, getMediaType, type Media } from '../lib/tmdb';

interface TrailerModalProps {
  media: Media | null;
  onClose: () => void;
}

export function TrailerModal({ media, onClose }: TrailerModalProps) {
  const [videoKey, setVideoKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!media) return;
    let active = true;
    setLoading(true);
    setError(null);
    setVideoKey(null);

    (async () => {
      try {
        const type = getMediaType(media);
        const data =
          type === 'tv'
            ? await tmdb.tvVideos(media.id)
            : await tmdb.movieVideos(media.id);

        if (!active) return;

        // Find best trailer
        const trailer =
          data.results.find((v) => v.type === 'Trailer' && v.site === 'YouTube') ||
          data.results.find((v) => v.type === 'Teaser' && v.site === 'YouTube') ||
          data.results.find((v) => v.site === 'YouTube');

        if (trailer) {
          setVideoKey(trailer.key);
        } else {
          setError('No trailer available for this title.');
        }
      } catch (e: any) {
        if (active) setError(e.message || 'Failed to load trailer.');
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [media]);

  // Close on Escape key
  useEffect(() => {
    if (!media) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [media, onClose]);

  if (!media) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl animate-scale-in rounded-xl bg-zinc-900 shadow-2xl ring-1 ring-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
          <div className="flex items-center gap-2">
            <span className="text-lg">🎬</span>
            <h3 className="truncate text-sm font-bold text-white sm:text-base">
              {getTitle(media)} — Trailer
            </h3>
          </div>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-red-600 hover:text-white"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Video / Loading / Error */}
        <div className="aspect-video w-full overflow-hidden rounded-b-xl bg-black">
          {loading ? (
            <div className="flex h-full w-full flex-col items-center justify-center gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-red-600" />
              <p className="text-sm text-zinc-400">Loading trailer...</p>
            </div>
          ) : error ? (
            <div className="flex h-full w-full flex-col items-center justify-center gap-3 px-4 text-center">
              <span className="text-4xl">😕</span>
              <p className="text-sm text-zinc-400">{error}</p>
              <button
                onClick={onClose}
                className="mt-2 rounded-full bg-red-600 px-5 py-2 text-xs font-bold text-white transition hover:bg-red-700"
              >
                Close
              </button>
            </div>
          ) : videoKey ? (
            <iframe
              src={`https://www.youtube.com/embed/${videoKey}?autoplay=1&rel=0`}
              title={`${getTitle(media)} Trailer`}
              className="h-full w-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
