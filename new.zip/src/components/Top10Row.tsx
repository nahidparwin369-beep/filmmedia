import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Star, Plus, Check, Play } from 'lucide-react';
import { img, getTitle, getYear, getMediaType, type Media } from '../lib/tmdb';
import { useWatchlist } from '../lib/watchlist';

interface Top10RowProps {
  title: string;
  items: Media[];
  accent?: string;
}

export function Top10Row({ title, items, accent }: Top10RowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = scrollRef.current.clientWidth * 0.8;
    scrollRef.current.scrollBy({
      left: dir === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  const top10 = items.slice(0, 10);

  return (
    <section className="group/row relative py-4">
      <div className="flex items-center gap-2 px-4 sm:px-8 mb-3">
        {accent && <span className="text-lg">{accent}</span>}
        <h2 className="text-base sm:text-xl font-bold text-white">{title}</h2>
        <span className="ml-1 h-1 w-1 rounded-full bg-red-600" />
      </div>

      <div className="relative">
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-0 z-30 hidden h-full w-10 items-center justify-center bg-gradient-to-r from-black/80 to-transparent opacity-0 transition-opacity group-hover/row:opacity-100 sm:flex"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-8 w-8 text-white" />
        </button>

        <div
          ref={scrollRef}
          className="flex gap-2 overflow-x-auto scroll-smooth px-4 sm:px-8 pb-4 scrollbar-none"
          style={{ scrollbarWidth: 'none' }}
        >
          {top10.map((m, i) => (
            <Top10Card key={`${m.id}-${i}`} media={m} rank={i + 1} />
          ))}
        </div>

        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-0 z-30 hidden h-full w-10 items-center justify-center bg-gradient-to-l from-black/80 to-transparent opacity-0 transition-opacity group-hover/row:opacity-100 sm:flex"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-8 w-8 text-white" />
        </button>
      </div>
    </section>
  );
}

function Top10Card({ media, rank }: { media: Media; rank: number }) {
  const { isInList, toggle } = useWatchlist();
  const type = getMediaType(media);
  const inList = isInList(media.id);
  const poster = img(media.poster_path, 'w342');

  return (
    <div className="group relative flex flex-shrink-0 items-end">
      {/* Giant number */}
      <span
        className="top10-number pointer-events-none select-none text-[100px] sm:text-[140px] text-zinc-700 leading-none"
        style={{ marginRight: '-20px', zIndex: 0 }}
      >
        {rank}
      </span>

      {/* Card */}
      <Link
        to={`/${type}/${media.id}`}
        className="group relative z-10 w-[120px] sm:w-[150px] flex-shrink-0 transition-transform duration-300 hover:scale-105 hover:z-20"
      >
        <div className="relative aspect-[2/3] overflow-hidden rounded-lg bg-zinc-800 shadow-xl">
          {poster ? (
            <img
              src={poster}
              alt={getTitle(media)}
              loading="lazy"
              className="h-full w-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center p-2 text-center text-xs text-zinc-600">
              {getTitle(media)}
            </div>
          )}

          {/* Rating badge */}
          <div className="absolute top-1.5 left-1.5 flex items-center gap-0.5 rounded-md bg-black/70 backdrop-blur px-1.5 py-0.5">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            <span className="text-[10px] font-semibold text-white">
              {media.vote_average ? media.vote_average.toFixed(1) : '—'}
            </span>
          </div>

          {/* Rank badge */}
          <div className="absolute top-1.5 right-1.5 grid h-6 w-6 place-items-center rounded-full bg-red-600 text-[11px] font-black text-white shadow-lg">
            {rank}
          </div>

          {/* Hover overlay */}
          <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/90 via-black/20 to-transparent p-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
            <p className="line-clamp-2 text-[11px] text-zinc-200">
              {media.overview || 'No description available.'}
            </p>
          </div>

          {/* Watchlist button */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toggle(media);
            }}
            className={`absolute bottom-1.5 right-1.5 grid h-7 w-7 place-items-center rounded-full backdrop-blur transition-all ${
              inList ? 'bg-green-500 text-white' : 'bg-black/70 text-white hover:bg-red-600'
            }`}
            title={inList ? 'Remove from watchlist' : 'Add to watchlist'}
          >
            {inList ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
          </button>
        </div>

        <div className="mt-1.5">
          <h3 className="truncate text-xs font-medium text-zinc-200 group-hover:text-white">
            {getTitle(media)}
          </h3>
          <p className="text-[10px] text-zinc-500">{getYear(media)}</p>
        </div>
      </Link>
    </div>
  );
}
