import { useState } from 'react';
import { Star, X, Heart, Check } from 'lucide-react';
import { useSiteRating } from '../lib/siteRating';

export function WebsiteRating() {
  const { stats, rate } = useSiteRating();
  const [hover, setHover] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [popupRating, setPopupRating] = useState(0);

  const handleClick = (value: number) => {
    const result = rate(value);
    setPopupRating(value);
    setShowPopup(true);
    // Auto-hide popup after 3 seconds
    setTimeout(() => setShowPopup(false), 3000);
    void result;
  };

  const displayValue = hover || stats.userRating || 0;
  const hasRated = stats.userRating !== null;

  return (
    <section className="border-t border-white/10 bg-zinc-950 px-4 py-12 sm:px-8">
      <div className="mx-auto max-w-2xl text-center">
        {/* Title */}
        <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
          Rate Us
        </h2>
        <p className="mt-2 text-sm text-zinc-400 sm:text-base">
          How was your experience on Film Media?
        </p>

        {/* Stars */}
        <div className="mt-6 flex items-center justify-center gap-2 sm:gap-3">
          {[1, 2, 3, 4, 5].map((star) => {
            const isFilled = star <= displayValue;
            return (
              <button
                key={star}
                onMouseEnter={() => setHover(star)}
                onMouseLeave={() => setHover(0)}
                onClick={() => handleClick(star)}
                disabled={hasRated}
                className={`group relative transition-all duration-200 ${
                  hasRated ? 'cursor-default' : 'cursor-pointer hover:scale-125'
                }`}
                aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
              >
                <Star
                  className={`h-10 w-10 transition-all duration-300 sm:h-12 sm:w-12 ${
                    isFilled
                      ? 'fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.6)]'
                      : 'fill-zinc-800 text-zinc-700 group-hover:fill-zinc-700 group-hover:text-zinc-500'
                  } ${!hasRated ? 'group-hover:scale-110' : ''}`}
                />
              </button>
            );
          })}
        </div>

        {/* Status message */}
        <div className="mt-5 min-h-[3rem]">
          {hasRated ? (
            <div className="flex items-center justify-center gap-2 text-sm font-semibold text-green-500">
              <Check className="h-4 w-4" />
              Thanks for rating! You rated {stats.userRating} star{stats.userRating! > 1 ? 's' : ''}.
            </div>
          ) : (
            <p className="text-xs text-zinc-600">
              Click a star to share your feedback
            </p>
          )}
        </div>

        {/* Average rating display */}
        <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-zinc-900 px-5 py-2.5 ring-1 ring-white/10">
          <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
          <span className="text-lg font-bold text-white">
            {stats.average.toFixed(1)}
          </span>
          <span className="text-sm text-zinc-500">/ 5</span>
          <span className="ml-1 text-sm text-zinc-500">
            ({stats.total.toLocaleString()} rating{stats.total !== 1 ? 's' : ''})
          </span>
        </div>
      </div>

      {/* Thank you popup */}
      {showPopup && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          onClick={() => setShowPopup(false)}
        >
          <div
            className="relative w-full max-w-sm animate-scale-in rounded-2xl bg-gradient-to-b from-zinc-900 to-zinc-950 p-8 text-center shadow-2xl ring-1 ring-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowPopup(false)}
              className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-zinc-800 text-zinc-400 transition hover:bg-red-600 hover:text-white"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Animated heart */}
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-red-600/20">
              <Heart className="h-8 w-8 fill-red-600 text-red-600 animate-pulse" />
            </div>

            <h3 className="text-xl font-extrabold text-white">
              Thank You! 🎉
            </h3>
            <p className="mt-2 text-sm text-zinc-400">
              You rated Film Media{' '}
              <span className="font-bold text-yellow-400">
                {popupRating} star{popupRating > 1 ? 's' : ''}
              </span>
            </p>

            {/* Show stars in popup */}
            <div className="mt-3 flex items-center justify-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={`h-6 w-6 ${
                    s <= popupRating
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'fill-zinc-800 text-zinc-700'
                  }`}
                />
              ))}
            </div>

            <p className="mt-4 text-xs text-zinc-500">
              We appreciate your feedback!
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
