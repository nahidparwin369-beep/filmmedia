export function CardSkeleton({ fullWidth = false }: { fullWidth?: boolean }) {
  return (
    <div className={`${fullWidth ? 'w-full' : 'w-[160px] sm:w-[180px]'} flex-shrink-0`}>
      <div className="aspect-[2/3] rounded-lg bg-zinc-800/60 animate-pulse" />
      <div className="mt-2 h-3 w-3/4 rounded bg-zinc-800/60 animate-pulse" />
      <div className="mt-1.5 h-2.5 w-1/2 rounded bg-zinc-800/40 animate-pulse" />
    </div>
  );
}

export function RowSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="flex gap-3 overflow-hidden px-4 sm:px-8">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <div className="relative h-[55vh] sm:h-[70vh] w-full bg-zinc-900 animate-pulse">
      <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-12">
        <div className="h-10 w-2/3 max-w-xl rounded bg-zinc-800 animate-pulse" />
        <div className="mt-4 h-4 w-1/2 max-w-md rounded bg-zinc-800/70 animate-pulse" />
        <div className="mt-4 h-3 w-1/3 max-w-xs rounded bg-zinc-800/50 animate-pulse" />
      </div>
    </div>
  );
}

export function GridSkeleton({ count = 12 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} fullWidth />
      ))}
    </div>
  );
}

export function DetailSkeleton() {
  return (
    <div className="min-h-screen">
      <div className="h-[40vh] sm:h-[55vh] w-full bg-zinc-900 animate-pulse" />
      <div className="px-4 sm:px-8 -mt-20 sm:-mt-32 relative">
        <div className="flex flex-col sm:flex-row gap-6">
          <div className="w-32 sm:w-52 aspect-[2/3] rounded-lg bg-zinc-800 animate-pulse" />
          <div className="flex-1 space-y-3 pt-4">
            <div className="h-8 w-2/3 rounded bg-zinc-800 animate-pulse" />
            <div className="h-4 w-1/2 rounded bg-zinc-800/70 animate-pulse" />
            <div className="h-3 w-full rounded bg-zinc-800/50 animate-pulse" />
            <div className="h-3 w-5/6 rounded bg-zinc-800/50 animate-pulse" />
            <div className="h-3 w-4/6 rounded bg-zinc-800/50 animate-pulse" />
          </div>
        </div>
      </div>
    </div>
  );
}
