import { useState, useEffect, useCallback } from 'react';

export interface Review {
  id: string;
  mediaId: number;
  name: string;
  rating: number;
  text: string;
  date: string;
}

const KEY = 'cineworld_reviews';

function readAll(): Review[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeAll(reviews: Review[]) {
  localStorage.setItem(KEY, JSON.stringify(reviews));
  window.dispatchEvent(new Event('reviews-change'));
}

export function useReviews(mediaId: number) {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    const load = () => {
      setReviews(
        readAll()
          .filter((r) => r.mediaId === mediaId)
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      );
    };
    load();
    window.addEventListener('reviews-change', load);
    return () => window.removeEventListener('reviews-change', load);
  }, [mediaId]);

  const addReview = useCallback(
    (name: string, rating: number, text: string) => {
      const review: Review = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        mediaId,
        name: name.trim() || 'Anonymous',
        rating,
        text: text.trim(),
        date: new Date().toISOString(),
      };
      writeAll([review, ...readAll()]);
    },
    [mediaId]
  );

  const deleteReview = useCallback((id: string) => {
    writeAll(readAll().filter((r) => r.id !== id));
  }, []);

  return { reviews, addReview, deleteReview };
}
