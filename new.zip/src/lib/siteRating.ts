import { useState, useEffect, useCallback } from 'react';

export interface RatingStats {
  total: number;
  sum: number;
  average: number;
  userRating: number | null;
}

const KEY = 'cineworld_site_rating';

interface StoredData {
  total: number;
  sum: number;
  userRating: number | null;
}

function read(): StoredData {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return { total: 0, sum: 0, userRating: null };
}

function write(data: StoredData) {
  localStorage.setItem(KEY, JSON.stringify(data));
  window.dispatchEvent(new Event('site-rating-change'));
}

// Seed with a realistic baseline so the site doesn't start at 0 ratings
const BASELINE = { total: 127, sum: 548 }; // ~4.3 average

function getStats(): RatingStats {
  const data = read();
  const total = data.total + BASELINE.total;
  const sum = data.sum + BASELINE.sum;
  return {
    total,
    sum,
    average: total > 0 ? sum / total : 0,
    userRating: data.userRating,
  };
}

export function useSiteRating() {
  const [stats, setStats] = useState<RatingStats>(getStats);

  useEffect(() => {
    const handler = () => setStats(getStats());
    window.addEventListener('site-rating-change', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('site-rating-change', handler);
      window.removeEventListener('storage', handler);
    };
  }, []);

  const rate = useCallback((rating: number): { isNew: boolean } => {
    const data = read();
    if (data.userRating !== null) {
      // Already rated — update their rating
      const diff = rating - data.userRating;
      write({ ...data, sum: data.sum + diff, userRating: rating });
      return { isNew: false };
    }
    // New rating
    write({
      total: data.total + 1,
      sum: data.sum + rating,
      userRating: rating,
    });
    return { isNew: true };
  }, []);

  return { stats, rate };
}
