import type { Media } from './tmdb';

export interface Badge {
  label: string;
  color: string;
  bg: string;
}

/**
 * Determine which badges to show on a movie card:
 * - NEW: released within last 30 days
 * - HOT: rating 8+
 * - TRENDING: trending items (media_type set by trending endpoint)
 */
export function getBadges(media: Media): Badge[] {
  const badges: Badge[] = [];

  // NEW badge — released within last 30 days
  const dateStr = media.release_date || media.first_air_date;
  if (dateStr) {
    const releaseDate = new Date(dateStr);
    const now = new Date();
    const diffDays = (now.getTime() - releaseDate.getTime()) / (1000 * 60 * 60 * 24);
    if (diffDays >= 0 && diffDays <= 30) {
      badges.push({
        label: 'NEW',
        color: 'text-white',
        bg: 'bg-red-600',
      });
    }
  }

  // HOT badge — rating 8+
  if (media.vote_average && media.vote_average >= 8) {
    badges.push({
      label: 'HOT',
      color: 'text-white',
      bg: 'bg-orange-500',
    });
  }

  // TRENDING badge — trending items have popularity > 100 typically
  if ((media.popularity && media.popularity > 100) || media.media_type === 'trending') {
    badges.push({
      label: 'TRENDING',
      color: 'text-white',
      bg: 'bg-blue-600',
    });
  }

  return badges;
}

/** Get the single most prominent badge (for compact display) */
export function getTopBadge(media: Media): Badge | null {
  const badges = getBadges(media);
  // Priority: NEW > HOT > TRENDING
  const priority = ['NEW', 'HOT', 'TRENDING'];
  for (const label of priority) {
    const found = badges.find((b) => b.label === label);
    if (found) return found;
  }
  return null;
}
