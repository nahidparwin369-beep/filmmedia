// TMDB API Helper
const API_KEY = 'f600e25c1c32550d870774f4a27a1084';
const BASE_URL = 'https://api.themoviedb.org/3';
export const IMG_BASE = 'https://image.tmdb.org/t/p';

export const img = (path: string | null | undefined, size: string = 'w500') =>
  path ? `${IMG_BASE}/${size}${path}` : '';

export interface Media {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  backdrop_path: string | null;
  overview: string;
  vote_average: number;
  vote_count: number;
  release_date?: string;
  first_air_date?: string;
  genre_ids?: number[];
  media_type?: string;
  original_language?: string;
  original_title?: string;
  popularity?: number;
}

export interface Genre {
  id: number;
  name: string;
}

export interface CastMember {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
}

export interface CrewMember {
  id: number;
  name: string;
  job: string;
  department: string;
}

export interface MediaDetail extends Media {
  genres: Genre[];
  runtime?: number;
  number_of_seasons?: number;
  number_of_episodes?: number;
  status?: string;
  tagline?: string;
  homepage?: string;
  production_companies?: { id: number; name: string }[];
  spoken_languages?: { english_name: string; name: string }[];
  seasons?: any[];
  credits?: { cast: CastMember[]; crew: CrewMember[] };
  similar?: { results: Media[] };
  recommendations?: { results: Media[] };
  videos?: { results: any[] };
  watch_providers?: { results?: any };
}

export interface Person {
  id: number;
  name: string;
  biography: string;
  birthday: string | null;
  deathday: string | null;
  place_of_birth: string | null;
  profile_path: string | null;
  known_for_department: string;
  gender: number;
}

export interface PersonCredit {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  overview: string;
  media_type: string;
  character?: string;
  job?: string;
  popularity: number;
}

export interface PersonDetails extends Person {
  movie_credits?: { cast: PersonCredit[]; crew: PersonCredit[] };
  tv_credits?: { cast: PersonCredit[]; crew: PersonCredit[] };
  combined_credits?: { cast: PersonCredit[]; crew: PersonCredit[] };
}

/** Fetch JSON from TMDB with timeout and error handling */
async function fetchJSON<T>(endpoint: string): Promise<T> {
  const url = `${BASE_URL}${endpoint}${endpoint.includes('?') ? '&' : '?'}api_key=${API_KEY}&language=en-US`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      throw new Error(`TMDB API error: ${res.status} ${res.statusText}`);
    }

    const data = await res.json();
    return data as T;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('Request timed out. Please check your connection.');
    }
    throw err;
  }
}

export const tmdb = {
  trending: () => fetchJSON<{ results: Media[] }>(`/trending/all/week`),
  trendingMovies: () => fetchJSON<{ results: Media[] }>(`/trending/movie/week`),
  trendingTV: () => fetchJSON<{ results: Media[] }>(`/trending/tv/week`),
  topRatedMovies: (page = 1) => fetchJSON<{ results: Media[] }>(`/movie/top_rated?page=${page}`),
  popularTV: (page = 1) => fetchJSON<{ results: Media[] }>(`/tv/popular?page=${page}`),
  nowPlaying: (page = 1) => fetchJSON<{ results: Media[] }>(`/movie/now_playing?page=${page}`),
  upcoming: (page = 1) => fetchJSON<{ results: Media[] }>(`/movie/upcoming?page=${page}`),
  popularMovies: (page = 1) => fetchJSON<{ results: Media[] }>(`/movie/popular?page=${page}`),
  airingToday: (page = 1) => fetchJSON<{ results: Media[] }>(`/tv/airing_today?page=${page}`),

  search: (query: string, page = 1) =>
    fetchJSON<{ results: Media[]; total_pages: number; total_results: number }>(
      `/search/multi?query=${encodeURIComponent(query)}&page=${page}&include_adult=false`
    ),

  movieDetails: (id: number) =>
    fetchJSON<MediaDetail>(`/movie/${id}?append_to_response=credits,similar,recommendations,videos,watch/providers`),
  tvDetails: (id: number) =>
    fetchJSON<MediaDetail>(`/tv/${id}?append_to_response=credits,similar,recommendations,videos,watch/providers`),

  movieGenres: () => fetchJSON<{ genres: Genre[] }>(`/genre/movie/list`),
  tvGenres: () => fetchJSON<{ genres: Genre[] }>(`/genre/tv/list`),

  discoverMovies: (params: Record<string, string | number>) =>
    fetchJSON<{ results: Media[]; total_pages: number }>(`/discover/movie?${new URLSearchParams(params as any).toString()}`),
  discoverTV: (params: Record<string, string | number>) =>
    fetchJSON<{ results: Media[]; total_pages: number }>(`/discover/tv?${new URLSearchParams(params as any).toString()}`),

  genreMovies: (genreId: number, page = 1, sort = 'popularity.desc') =>
    fetchJSON<{ results: Media[]; total_pages: number }>(`/discover/movie?with_genres=${genreId}&page=${page}&sort_by=${sort}`),
  genreTV: (genreId: number, page = 1, sort = 'popularity.desc') =>
    fetchJSON<{ results: Media[]; total_pages: number }>(`/discover/tv?with_genres=${genreId}&page=${page}&sort_by=${sort}`),

  // Person / Actor API
  personDetails: (id: number) =>
    fetchJSON<PersonDetails>(`/person/${id}?append_to_response=combined_credits`),

  // Trailer fetch for a specific movie/tv
  movieVideos: (id: number) =>
    fetchJSON<{ results: any[] }>(`/movie/${id}/videos`),
  tvVideos: (id: number) =>
    fetchJSON<{ results: any[] }>(`/tv/${id}/videos`),
};

// Common genres mapping (TMDB genre IDs are consistent across movie/tv)
export const CATEGORY_GENRES: { id: number; name: string; icon: string }[] = [
  { id: 28, name: 'Action', icon: '💥' },
  { id: 27, name: 'Horror', icon: '👻' },
  { id: 35, name: 'Comedy', icon: '😂' },
  { id: 10749, name: 'Romance', icon: '❤️' },
  { id: 53, name: 'Thriller', icon: '🔪' },
  { id: 878, name: 'Sci-Fi', icon: '🚀' },
  { id: 18, name: 'Drama', icon: '🎭' },
  { id: 16, name: 'Animation', icon: '🎬' },
  { id: 99, name: 'Documentary', icon: '📽️' },
];

/**
 * TMDB uses DIFFERENT genre IDs for Movies vs TV.
 * Movie genre IDs like 28 (Action), 27 (Horror), 878 (Sci-Fi) do NOT work
 * on the /discover/tv endpoint and return 0 results.
 * This map translates the shared CATEGORY_GENRES movie IDs to their TV equivalents.
 */
export const TV_GENRE_MAP: Record<number, number> = {
  28: 10759,    // Action -> Action & Adventure
  27: 9648,     // Horror -> Mystery (TMDB has no pure "Horror" TV genre; Mystery is closest)
  35: 35,       // Comedy -> Comedy (same)
  10749: 10749, // Romance -> Romance (same, works on TV)
  53: 80,       // Thriller -> Crime (closest TV equivalent; 53 doesn't exist for TV)
  878: 10765,   // Sci-Fi -> Sci-Fi & Fantasy
  18: 18,       // Drama -> Drama (same)
  16: 16,       // Animation -> Animation (same)
  99: 99,       // Documentary -> Documentary (same)
};

/** Get the correct genre ID for the given media type */
export function getGenreId(movieGenreId: number, mediaType: 'movie' | 'tv'): number {
  if (mediaType === 'tv') {
    return TV_GENRE_MAP[movieGenreId] ?? movieGenreId;
  }
  return movieGenreId;
}

export const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ko', name: 'Korean' },
  { code: 'ta', name: 'Tamil' },
];

export const STREAMING_PLATFORMS = [
  { name: 'Netflix', color: '#E50914' },
  { name: 'Prime Video', color: '#00A8E1' },
  { name: 'Disney+ Hotstar', color: '#113CCF' },
  { name: 'JioCinema', color: '#0F3D8A' },
  { name: 'SonyLIV', color: '#0A1A33' },
  { name: 'Apple TV+', color: '#000000' },
];

export function getTitle(m: Media): string {
  return m.title || m.name || m.original_title || 'Untitled';
}

export function getYear(m: Media): string {
  const d = m.release_date || m.first_air_date;
  return d ? d.slice(0, 4) : '—';
}

export function getMediaType(m: Media): 'movie' | 'tv' {
  if (m.media_type === 'tv') return 'tv';
  if (m.media_type === 'movie') return 'movie';
  if (m.first_air_date && !m.release_date) return 'tv';
  return 'movie';
}
