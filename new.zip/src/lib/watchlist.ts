import { useState, useEffect, useCallback } from 'react';
import type { Media } from './tmdb';

const KEY = 'cineworld_watchlist';

function read(): Media[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function write(items: Media[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event('watchlist-change'));
}

export function useWatchlist() {
  const [items, setItems] = useState<Media[]>(read());

  useEffect(() => {
    const handler = () => setItems(read());
    window.addEventListener('watchlist-change', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('watchlist-change', handler);
      window.removeEventListener('storage', handler);
    };
  }, []);

  const isInList = useCallback(
    (id: number) => items.some((i) => i.id === id),
    [items]
  );

  const toggle = useCallback((m: Media) => {
    const current = read();
    const exists = current.some((i) => i.id === m.id);
    const next = exists
      ? current.filter((i) => i.id !== m.id)
      : [...current, m];
    write(next);
  }, []);

  const remove = useCallback((id: number) => {
    write(read().filter((i) => i.id !== id));
  }, []);

  const clear = useCallback(() => write([]), []);

  return { items, isInList, toggle, remove, clear, count: items.length };
}
