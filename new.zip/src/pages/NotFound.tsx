import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Film, Home, Clapperboard, AlertTriangle } from 'lucide-react';
import { tmdb, img, getTitle, getMediaType, type Media } from '../lib/tmdb';
import { MovieCard } from '../components/MovieCard';
import { PageLoader } from '../components/LoadingSpinner';

export default function NotFound() {
  const navigate = useNavigate();
  const [suggestions, setSuggestions] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const data = await tmdb.popularMovies();
        if (!active) return;
        // Pick 3 random from first 20 results
        const shuffled = [...data.results]
          .filter((m) => m.poster_path)
          .sort(() => Math.random() - 0.5)
          .slice(0, 3);
        setSuggestions(shuffled);
      } catch {
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 pt-20">
      <div className="mx-auto max-w-2xl px-4 py-12 text-center sm:px-8">
        {/* Movie-themed illustration */}
        <div className="relative mx-auto mb-8 w-fit">
          <div className="absolute inset-0 animate-pulse rounded-full bg-red-600/20 blur-2xl" />
          <div className="relative grid h-32 w-32 place-items-center rounded-full bg-gradient-to-br from-zinc-800 to-zinc-900 ring-2 ring-red-600/30">
            <Clapperboard className="h-16 w-16 text-red-600" />
          </div>
        </div>

        {/* 404 text */}
        <h1 className="text-6xl font-black text-white sm:text-7xl">404</h1>
        <div className="mt-4 flex items-center justify-center gap-2 text-lg font-semibold text-red-600">
          <AlertTriangle className="h-5 w-5" />
          Page Not Found
        </div>
        <p className="mt-4 text-base text-zinc-400 sm:text-lg">
          Oops! This page went missing like a deleted scene!
        </p>

        {/* Go back home button */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 rounded-full bg-zinc-800 px-6 py-2.5 text-sm font-bold text-white ring-1 ring-white/10 transition hover:bg-zinc-700"
          >
            <Film className="h-4 w-4" /> Go Back
          </button>
          <Link
            to="/"
            className="flex items-center gap-2 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
          >
            <Home className="h-4 w-4" /> Go Back Home
          </Link>
        </div>
      </div>

      {/* Suggested movies */}
      <div className="mx-auto max-w-[1200px] px-4 pb-12 sm:px-8">
        <h2 className="mb-4 text-center text-sm font-bold uppercase tracking-wide text-zinc-500">
          🎬 While you're here, check these out
        </h2>
        {loading ? (
          <PageLoader />
        ) : suggestions.length > 0 ? (
          <div className="grid grid-cols-3 gap-3 sm:gap-4">
            {suggestions.map((m, i) => (
              <MovieCard
                key={m.id}
                media={{ ...m, media_type: 'movie' }}
                index={i}
                fullWidth
              />
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}
