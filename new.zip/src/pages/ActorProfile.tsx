import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, AlertCircle, Cake, MapPin, Film, Star, Users } from 'lucide-react';
import { tmdb, img, getTitle, getMediaType, type PersonDetails, type PersonCredit, type Media } from '../lib/tmdb';
import { MovieCard } from '../components/MovieCard';
import { DetailSkeleton } from '../components/Skeleton';

export default function ActorProfile() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [person, setPerson] = useState<PersonDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    let active = true;
    setLoading(true);
    setError(null);
    setPerson(null);
    (async () => {
      try {
        const data = await tmdb.personDetails(Number(id));
        if (active) setPerson(data);
      } catch (e: any) {
        if (active) setError(e.message || 'Failed to load actor profile.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 pt-20">
        <DetailSkeleton />
      </div>
    );
  }

  if (error || !person) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-950 px-4 pt-20 text-center">
        <AlertCircle className="h-12 w-12 text-red-600" />
        <p className="mt-4 text-lg font-semibold text-white">
          {error || 'Actor not found'}
        </p>
        <button
          onClick={() => navigate(-1)}
          className="mt-4 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
        >
          Go Back
        </button>
      </div>
    );
  }

  // Get known for credits (sorted by popularity)
  const allCredits = person.combined_credits?.cast || [];
  const knownFor = [...allCredits]
    .filter((c) => c.poster_path)
    .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
    .slice(0, 12);

  // All credits sorted by date (most recent first)
  const allSorted = [...allCredits]
    .filter((c) => c.poster_path)
    .sort((a, b) => {
      const da = new Date(a.release_date || a.first_air_date || '1970').getTime();
      const db = new Date(b.release_date || b.first_air_date || '1970').getTime();
      return db - da;
    });

  const age = person.birthday
    ? Math.floor(
        (Date.now() - new Date(person.birthday).getTime()) /
          (365.25 * 24 * 60 * 60 * 1000)
      )
    : null;

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Header banner */}
      <div className="relative h-[30vh] w-full overflow-hidden bg-zinc-900 sm:h-[35vh]">
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-800/50 to-zinc-950" />
        <button
          onClick={() => navigate(-1)}
          className="absolute left-4 top-20 grid h-10 w-10 place-items-center rounded-full bg-black/50 text-white backdrop-blur transition hover:bg-black/70"
          aria-label="Go back"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
      </div>

      <div className="relative z-10 -mt-24 px-4 pb-12 sm:-mt-28 sm:px-8">
        <div className="mx-auto max-w-[1200px]">
          <div className="flex flex-col gap-6 sm:flex-row">
            {/* Profile photo */}
            <div className="mx-auto w-40 flex-shrink-0 sm:mx-0 sm:w-48">
              <div className="aspect-[2/3] overflow-hidden rounded-xl shadow-2xl ring-1 ring-white/10">
                {person.profile_path ? (
                  <img
                    src={img(person.profile_path, 'w500')}
                    alt={person.name}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="grid h-full w-full place-items-center bg-zinc-800 text-zinc-600">
                    <Users className="h-12 w-12" />
                  </div>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="flex-1">
              <h1 className="text-2xl font-extrabold text-white sm:text-4xl">
                {person.name}
              </h1>
              <p className="mt-1 text-sm text-red-500">
                {person.known_for_department}
              </p>

              <div className="mt-4 flex flex-wrap gap-4 text-sm text-zinc-300">
                {person.birthday && (
                  <span className="flex items-center gap-1.5">
                    <Cake className="h-4 w-4 text-zinc-500" />
                    {new Date(person.birthday).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                    })}
                    {age !== null && ` (${age} years old)`}
                  </span>
                )}
                {person.place_of_birth && (
                  <span className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4 text-zinc-500" />
                    {person.place_of_birth}
                  </span>
                )}
              </div>

              {/* Biography */}
              {person.biography && (
                <div className="mt-5">
                  <h3 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-zinc-400">
                    Biography
                  </h3>
                  <p className="max-w-3xl text-sm leading-relaxed text-zinc-300">
                    {person.biography}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Known For */}
          {knownFor.length > 0 && (
            <div className="mt-10">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white">
                <Star className="h-5 w-5 text-red-600" /> Known For
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-6">
                {knownFor.map((c, i) => (
                  <MovieCard
                    key={`${c.id}-${i}`}
                    media={creditToMedia(c)}
                    index={i}
                    fullWidth
                  />
                ))}
              </div>
            </div>
          )}

          {/* All Credits */}
          {allSorted.length > 0 && (
            <div className="mt-10">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white">
                <Film className="h-5 w-5 text-red-600" /> Filmography
                <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-xs font-medium text-zinc-400">
                  {allSorted.length}
                </span>
              </h2>
              <div className="space-y-2">
                {allSorted.slice(0, 20).map((c, i) => {
                  const type = c.media_type === 'tv' ? 'tv' : 'movie';
                  const date = c.release_date || c.first_air_date;
                  return (
                    <Link
                      key={`${c.id}-${i}`}
                      to={`/${type}/${c.id}`}
                      className="flex items-center gap-3 rounded-lg bg-zinc-900 p-3 ring-1 ring-white/5 transition hover:bg-zinc-800"
                    >
                      <div className="h-16 w-12 flex-shrink-0 overflow-hidden rounded bg-zinc-800">
                        {c.poster_path ? (
                          <img
                            src={img(c.poster_path, 'w92')}
                            alt={getTitle(c as any)}
                            className="h-full w-full object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <div className="grid h-full w-full place-items-center">
                            <Film className="h-4 w-4 text-zinc-700" />
                          </div>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-white">
                          {getTitle(c as any)}
                        </p>
                        <p className="truncate text-xs text-zinc-500">
                          {c.character || c.job || '—'}
                        </p>
                      </div>
                      <div className="flex-shrink-0 text-right">
                        <p className="text-xs text-zinc-400">
                          {date ? date.slice(0, 4) : '—'}
                        </p>
                        <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[9px] font-bold uppercase text-zinc-400">
                          {type === 'tv' ? 'Series' : 'Movie'}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
              {allSorted.length > 20 && (
                <p className="mt-3 text-center text-xs text-zinc-500">
                  Showing 20 of {allSorted.length} credits
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function creditToMedia(c: PersonCredit): Media {
  return {
    id: c.id,
    title: c.title,
    name: c.name,
    poster_path: c.poster_path,
    backdrop_path: c.backdrop_path,
    overview: c.overview,
    vote_average: c.vote_average,
    vote_count: 0,
    release_date: c.release_date,
    first_air_date: c.first_air_date,
    media_type: c.media_type,
    popularity: c.popularity,
  };
}
