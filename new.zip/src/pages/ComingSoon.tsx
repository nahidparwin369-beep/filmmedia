import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, AlertCircle, RefreshCw, Film, Tv } from 'lucide-react';
import { tmdb, img, getTitle, getMediaType, type Media } from '../lib/tmdb';
import { GridSkeleton } from '../components/Skeleton';
import { Star, Plus, Check } from 'lucide-react';
import { useWatchlist } from '../lib/watchlist';

interface GroupedItem extends Media {
  releaseDate: string;
  monthKey: string;
  monthLabel: string;
}

export default function ComingSoon() {
  const [items, setItems] = useState<GroupedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [up1, up2, tvData] = await Promise.all([
        tmdb.upcoming(1),
        tmdb.upcoming(2),
        tmdb.popularTV(),
      ]);

      const allItems: GroupedItem[] = [
        ...up1.results,
        ...up2.results,
        ...tvData.results.slice(0, 10).map((m) => ({
          ...m,
          media_type: 'tv',
          release_date: m.first_air_date || m.release_date,
        })),
      ]
        .filter((m) => m.poster_path && (m.release_date || m.first_air_date))
        .map((m) => {
          const date = m.release_date || m.first_air_date || '';
          const d = new Date(date);
          return {
            ...m,
            releaseDate: date,
            monthKey: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`,
            monthLabel: d.toLocaleDateString('en-US', {
              month: 'long',
              year: 'numeric',
            }),
          };
        })
        .filter((m) => new Date(m.releaseDate) >= new Date())
        .sort((a, b) => new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime());

      // Deduplicate by id
      const seen = new Set<number>();
      const unique = allItems.filter((m) => {
        if (seen.has(m.id)) return false;
        seen.add(m.id);
        return true;
      });

      setItems(unique);
    } catch (e: any) {
      setError(e.message || 'Failed to load upcoming releases.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  // Group by month
  const grouped = items.reduce<Record<string, GroupedItem[]>>((acc, item) => {
    if (!acc[item.monthKey]) acc[item.monthKey] = [];
    acc[item.monthKey].push(item);
    return acc;
  }, {});
  const monthKeys = Object.keys(grouped).sort();

  if (error && !loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-950 px-4 pt-20 text-center">
        <AlertCircle className="h-12 w-12 text-red-600" />
        <p className="mt-4 text-lg font-semibold text-white">{error}</p>
        <button
          onClick={load}
          className="mt-4 flex items-center gap-2 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
        >
          <RefreshCw className="h-4 w-4" /> Retry
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 pt-20">
      <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold text-white sm:text-3xl">
            <Calendar className="h-7 w-7 text-red-600" /> Release Calendar
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Upcoming movies and series — sorted by release date
          </p>
        </div>

        {loading ? (
          <GridSkeleton count={12} />
        ) : (
          <div className="space-y-10">
            {monthKeys.map((key) => {
              const monthItems = grouped[key];
              return (
                <div key={key}>
                  {/* Month header */}
                  <div className="mb-4 flex items-center gap-3">
                    <div className="grid h-12 w-12 place-items-center rounded-xl bg-red-600 text-white">
                      <Calendar className="h-6 w-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">
                        {monthItems[0].monthLabel}
                      </h2>
                      <p className="text-xs text-zinc-500">
                        {monthItems.length} upcoming release{monthItems.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>

                  {/* Items grid */}
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                    {monthItems.map((m, i) => (
                      <ComingSoonCard key={`${m.id}-${i}`} media={m} />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function ComingSoonCard({ media }: { media: GroupedItem }) {
  const { isInList, toggle } = useWatchlist();
  const type = getMediaType(media);
  const inList = isInList(media.id);
  const poster = img(media.poster_path, 'w342');
  const d = new Date(media.releaseDate);

  return (
    <Link
      to={`/${type}/${media.id}`}
      className="group relative block transition-transform duration-300 hover:scale-105 hover:z-20"
    >
      <div className="relative aspect-[2/3] overflow-hidden rounded-lg bg-zinc-800 shadow-lg">
        {poster ? (
          <img
            src={poster}
            alt={getTitle(media)}
            loading="lazy"
            className="h-full w-full object-cover transition-opacity duration-300 group-hover:opacity-90"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center p-2 text-center text-xs text-zinc-600">
            {getTitle(media)}
          </div>
        )}

        {/* Release date badge */}
        <div className="absolute top-1.5 left-1.5 flex items-center gap-1 rounded-md bg-red-600/90 backdrop-blur px-1.5 py-0.5">
          <Calendar className="h-3 w-3 text-white" />
          <span className="text-[10px] font-bold text-white">
            {d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        </div>

        {/* Type badge */}
        <div className="absolute top-1.5 right-1.5 flex items-center gap-0.5 rounded bg-black/70 backdrop-blur px-1.5 py-0.5">
          {type === 'tv' ? (
            <Tv className="h-2.5 w-2.5 text-white" />
          ) : (
            <Film className="h-2.5 w-2.5 text-white" />
          )}
        </div>

        {/* Rating badge */}
        {media.vote_average > 0 && (
          <div className="absolute bottom-1.5 left-1.5 flex items-center gap-0.5 rounded-md bg-black/70 backdrop-blur px-1.5 py-0.5">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            <span className="text-[10px] font-semibold text-white">
              {media.vote_average.toFixed(1)}
            </span>
          </div>
        )}

        {/* Watchlist button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggle(media);
          }}
          className={`absolute bottom-1.5 right-1.5 grid h-7 w-7 place-items-center rounded-full backdrop-blur transition-all ${
            inList ? 'bg-green-500 text-white' : 'bg-black/70 text-white hover:bg-red-600'
          }`}
        >
          {inList ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
        </button>
      </div>

      <div className="mt-1.5">
        <h3 className="truncate text-xs font-medium text-zinc-200 group-hover:text-white">
          {getTitle(media)}
        </h3>
        <p className="text-[10px] text-zinc-500">
          {d.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          })}
        </p>
      </div>
    </Link>
  );
}
