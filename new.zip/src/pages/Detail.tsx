import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Star, Clock, Calendar, Globe, Plus, Check, Play, ArrowLeft, Tv, Users, AlertCircle, Share2 } from 'lucide-react';
import { tmdb, img, STREAMING_PLATFORMS, type MediaDetail } from '../lib/tmdb';
import { useWatchlist } from '../lib/watchlist';
import { formatRuntime, formatDate, formatCount } from '../lib/format';
import { DetailSkeleton } from '../components/Skeleton';
import { MovieCard } from '../components/MovieCard';
import { TrailerModal } from '../components/TrailerModal';
import { ShareModal } from '../components/ShareModal';
import { ReviewsSection } from '../components/ReviewsSection';

interface DetailProps {
  type: 'movie' | 'tv';
}

export default function Detail({ type }: DetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<MediaDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [trailerOpen, setTrailerOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const { isInList, toggle } = useWatchlist();

  useEffect(() => {
    if (!id) return;
    let active = true;
    setLoading(true);
    setError(null);
    setData(null);
    (async () => {
      try {
        const d =
          type === 'tv'
            ? await tmdb.tvDetails(Number(id))
            : await tmdb.movieDetails(Number(id));
        if (active) setData(d);
      } catch (e: any) {
        if (active) {
          setError(e.message || 'Failed to load details. Please try again.');
        }
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [id, type]);

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 pt-14">
        <DetailSkeleton />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-950 px-4 pt-14 text-center">
        <AlertCircle className="h-12 w-12 text-red-600" />
        <p className="mt-4 text-lg font-semibold text-white">{error || 'Title not found'}</p>
        <button
          onClick={() => navigate('/')}
          className="mt-4 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
        >
          Back to Home
        </button>
      </div>
    );
  }

  const isTV = type === 'tv';
  const title = data.title || data.name || 'Untitled';
  const date = data.release_date || data.first_air_date;
  const inList = isInList(data.id);
  const cast = data.credits?.cast?.slice(0, 12) || [];
  const director = data.credits?.crew?.find((c) => c.job === 'Director');
  const creators = isTV ? data.credits?.crew?.filter((c) => c.job === 'Creator') : [];
  const similar = (data.similar?.results || data.recommendations?.results || [])
    .filter((m) => m.poster_path)
    .slice(0, 12);

  const wp = data.watch_providers?.results || {};
  const providers =
    wp.IN?.flatrate || wp.US?.flatrate || wp.GB?.flatrate || [];

  const trailer = data.videos?.results?.find(
    (v) => v.type === 'Trailer' && v.site === 'YouTube'
  );

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Backdrop */}
      <div className="relative h-[40vh] w-full sm:h-[55vh]">
        {data.backdrop_path ? (
          <img
            src={img(data.backdrop_path, 'original')}
            alt={title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full bg-zinc-800" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950/70 to-transparent" />
        <button
          onClick={() => navigate(-1)}
          className="absolute left-4 top-20 grid h-10 w-10 place-items-center rounded-full bg-black/50 text-white backdrop-blur transition hover:bg-black/70"
          aria-label="Go back"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
      </div>

      <div className="relative z-10 -mt-24 px-4 pb-12 sm:-mt-32 sm:px-8">
        <div className="mx-auto max-w-[1400px]">
          <div className="flex flex-col gap-6 sm:flex-row">
            {/* Poster */}
            <div className="mx-auto w-36 flex-shrink-0 sm:mx-0 sm:w-52">
              <div className="aspect-[2/3] overflow-hidden rounded-xl shadow-2xl ring-1 ring-white/10">
                {data.poster_path ? (
                  <img
                    src={img(data.poster_path, 'w500')}
                    alt={title}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="grid h-full w-full place-items-center bg-zinc-800 text-zinc-600">
                    No Image
                  </div>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="flex-1">
              <h1 className="text-2xl font-extrabold text-white sm:text-4xl">{title}</h1>
              {data.tagline && (
                <p className="mt-1 text-sm italic text-zinc-400">{data.tagline}</p>
              )}

              <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-zinc-300">
                <span className="flex items-center gap-1 font-semibold text-yellow-400">
                  <Star className="h-4 w-4 fill-yellow-400" />
                  {data.vote_average?.toFixed(1)}
                </span>
                <span className="text-zinc-500">({formatCount(data.vote_count)} votes)</span>
                <span className="text-zinc-600">•</span>
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4 text-zinc-500" />
                  {date ? date.slice(0, 4) : '—'}
                </span>
                {!isTV && (
                  <>
                    <span className="text-zinc-600">•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-zinc-500" />
                      {formatRuntime(data.runtime)}
                    </span>
                  </>
                )}
                {isTV && (
                  <>
                    <span className="text-zinc-600">•</span>
                    <span className="flex items-center gap-1">
                      <Tv className="h-4 w-4 text-zinc-500" />
                      {data.number_of_seasons} Season{data.number_of_seasons !== 1 ? 's' : ''}
                    </span>
                  </>
                )}
                {data.original_language && (
                  <>
                    <span className="text-zinc-600">•</span>
                    <span className="flex items-center gap-1 uppercase">
                      <Globe className="h-4 w-4 text-zinc-500" />
                      {data.original_language}
                    </span>
                  </>
                )}
              </div>

              {/* Genre tags */}
              {data.genres?.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {data.genres.map((g) => (
                    <Link
                      key={g.id}
                      to={`/categories?genre=${g.id}`}
                      className="rounded-full bg-zinc-800 px-3 py-1 text-xs font-medium text-zinc-300 ring-1 ring-white/10 transition hover:bg-red-600 hover:text-white"
                    >
                      {g.name}
                    </Link>
                  ))}
                </div>
              )}

              {/* Action buttons */}
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button
                  onClick={() =>
                    toggle({
                      id: data.id,
                      title: data.title,
                      name: data.name,
                      poster_path: data.poster_path,
                      backdrop_path: data.backdrop_path,
                      overview: data.overview,
                      vote_average: data.vote_average,
                      vote_count: data.vote_count,
                      release_date: data.release_date,
                      first_air_date: data.first_air_date,
                      media_type: isTV ? 'tv' : 'movie',
                      original_language: data.original_language,
                    })
                  }
                  className={`flex items-center gap-2 rounded-md px-5 py-2.5 text-sm font-bold transition ${
                    inList
                      ? 'bg-green-600 text-white hover:bg-green-700'
                      : 'bg-white text-black hover:bg-white/80'
                  }`}
                >
                  {inList ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                  {inList ? 'In My List' : 'Add to List'}
                </button>
                {trailer && (
                  <button
                    onClick={() => setTrailerOpen(true)}
                    className="flex items-center gap-2 rounded-md bg-red-600 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
                  >
                    <Play className="h-4 w-4 fill-white" /> Watch Trailer
                  </button>
                )}
                <button
                  onClick={() => setShareOpen(true)}
                  className="flex items-center gap-2 rounded-md bg-zinc-800 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/10 transition hover:bg-blue-600"
                >
                  <Share2 className="h-4 w-4" /> Share
                </button>
              </div>
            </div>
          </div>

          {/* Overview */}
          <div className="mt-8">
            <h2 className="mb-2 text-lg font-bold text-white">Overview</h2>
            <p className="max-w-3xl text-sm leading-relaxed text-zinc-300 sm:text-base">
              {data.overview || 'No description available.'}
            </p>
          </div>

          {/* Director / Creator */}
          {(director || (creators && creators.length > 0)) && (
            <div className="mt-6">
              <h3 className="text-xs font-bold uppercase tracking-wide text-zinc-400">
                {isTV ? 'Creator' : 'Director'}
              </h3>
              <p className="mt-1 text-sm text-zinc-200">
                {director?.name ||
                  creators?.map((c) => c.name).join(', ') ||
                  '—'}
              </p>
            </div>
          )}

          {/* Where to Watch */}
          <div className="mt-8">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white">
              <Play className="h-5 w-5 text-red-600" /> Where to Watch
            </h2>
            {providers.length > 0 ? (
              <div className="flex flex-wrap gap-3">
                {providers.map((p: any) => (
                  <div
                    key={p.provider_id}
                    className="flex items-center gap-2 rounded-lg bg-zinc-900 px-3 py-2 ring-1 ring-white/10"
                  >
                    {p.logo_path && (
                      <img
                        src={img(p.logo_path, 'w92')}
                        alt={p.provider_name}
                        className="h-6 w-6 rounded"
                      />
                    )}
                    <span className="text-xs font-medium text-zinc-200">
                      {p.provider_name}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-wrap gap-3">
                {STREAMING_PLATFORMS.map((p) => (
                  <div
                    key={p.name}
                    className="flex items-center gap-2 rounded-lg bg-zinc-900 px-3 py-2 ring-1 ring-white/10"
                  >
                    <span
                      className="grid h-6 w-6 place-items-center rounded text-[10px] font-bold text-white"
                      style={{ backgroundColor: p.color }}
                    >
                      {p.name.charAt(0)}
                    </span>
                    <span className="text-xs font-medium text-zinc-200">{p.name}</span>
                  </div>
                ))}
              </div>
            )}
            <p className="mt-2 text-xs text-zinc-600">
              Availability may vary by region.
            </p>
          </div>

          {/* Cast - clickable */}
          {cast.length > 0 && (
            <div className="mt-8">
              <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white">
                <Users className="h-5 w-5 text-red-600" /> Top Cast
              </h2>
              <div
                className="flex gap-4 overflow-x-auto pb-2 scrollbar-none"
                style={{ scrollbarWidth: 'none' }}
              >
                {cast.map((c) => (
                  <Link
                    key={c.id}
                    to={`/actor/${c.id}`}
                    className="group w-20 flex-shrink-0 text-center transition-transform hover:scale-105 sm:w-24"
                  >
                    <div className="mx-auto aspect-square overflow-hidden rounded-full bg-zinc-800 ring-2 ring-white/5 transition group-hover:ring-red-600">
                      {c.profile_path ? (
                        <img
                          src={img(c.profile_path, 'w185')}
                          alt={c.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="grid h-full w-full place-items-center text-zinc-600">
                          <Users className="h-6 w-6" />
                        </div>
                      )}
                    </div>
                    <p className="mt-2 line-clamp-2 text-xs font-medium text-zinc-200 hover:text-red-400">
                      {c.name}
                    </p>
                    <p className="line-clamp-1 text-[10px] text-zinc-500">
                      {c.character}
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Additional info */}
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <InfoCard label="Status" value={data.status || '—'} />
            <InfoCard label="Released" value={formatDate(date)} />
            {isTV ? (
              <InfoCard
                label="Episodes"
                value={String(data.number_of_episodes || '—')}
              />
            ) : (
              <InfoCard label="Runtime" value={formatRuntime(data.runtime)} />
            )}
            <InfoCard
              label="Popularity"
              value={formatCount(Math.round(data.popularity || 0))}
            />
          </div>

          {/* Similar */}
          {similar.length > 0 && (
            <div className="mt-10">
              <h2 className="mb-3 text-lg font-bold text-white">More Like This</h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-6">
                {similar.map((m, i) => (
                  <MovieCard
                    key={m.id}
                    media={{ ...m, media_type: isTV ? 'tv' : 'movie' }}
                    index={i}
                    fullWidth
                  />
                ))}
              </div>
            </div>
          )}

          {/* User Reviews */}
          <ReviewsSection mediaId={data.id} mediaTitle={title} />
        </div>
      </div>

      {/* Trailer Modal */}
      {trailerOpen && trailer && (
        <TrailerModal
          media={{
            id: data.id,
            title: data.title,
            name: data.name,
            media_type: isTV ? 'tv' : 'movie',
            poster_path: data.poster_path,
            backdrop_path: data.backdrop_path,
            overview: data.overview,
            vote_average: data.vote_average,
            vote_count: data.vote_count,
            release_date: data.release_date,
            first_air_date: data.first_air_date,
          }}
          onClose={() => setTrailerOpen(false)}
        />
      )}

      {/* Share Modal */}
      {shareOpen && (
        <ShareModal
          media={{
            id: data.id,
            title: data.title,
            name: data.name,
            media_type: isTV ? 'tv' : 'movie',
            poster_path: data.poster_path,
            backdrop_path: data.backdrop_path,
            overview: data.overview,
            vote_average: data.vote_average,
            vote_count: data.vote_count,
            release_date: data.release_date,
            first_air_date: data.first_air_date,
          }}
          type={isTV ? 'tv' : 'movie'}
          onClose={() => setShareOpen(false)}
        />
      )}
    </div>
  );
}

function InfoCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-zinc-900 p-3 ring-1 ring-white/5">
      <p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">
        {label}
      </p>
      <p className="mt-1 text-sm font-medium text-zinc-200">{value}</p>
    </div>
  );
}
