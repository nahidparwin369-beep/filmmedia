import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon, SlidersHorizontal, X, AlertCircle } from 'lucide-react';
import { MovieCard } from '../components/MovieCard';
import { RatingFilter } from '../components/RatingFilter';
import { GridSkeleton } from '../components/Skeleton';
import { tmdb, CATEGORY_GENRES, LANGUAGES, TV_GENRE_MAP, type Media } from '../lib/tmdb';

type MediaType = 'all' | 'movie' | 'tv';

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const query = params.get('q') || '';

  const [results, setResults] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);

  // Filters
  const [mediaFilter, setMediaFilter] = useState<MediaType>('all');
  const [genre, setGenre] = useState<number | 'all'>('all');
  const [year, setYear] = useState<string>('all');
  const [lang, setLang] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [minRating, setMinRating] = useState(0);

  const [input, setInput] = useState(query);

  useEffect(() => {
    setInput(query);
  }, [query]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    let active = true;
    setLoading(true);
    setError(null);
    setPage(1);
    (async () => {
      try {
        const data = await tmdb.search(query, 1);
        if (!active) return;
        let filtered = data.results.filter(
          (m) => m.media_type === 'movie' || m.media_type === 'tv'
        );
        if (mediaFilter !== 'all')
          filtered = filtered.filter((m) => m.media_type === mediaFilter);
        if (genre !== 'all')
          filtered = filtered.filter((m) => matchesGenre(m, genre as number));
        if (year !== 'all')
          filtered = filtered.filter((m) =>
            (m.release_date || m.first_air_date || '').startsWith(year)
          );
        if (lang !== 'all')
          filtered = filtered.filter((m) => m.original_language === lang);
        if (minRating > 0)
          filtered = filtered.filter((m) => (m.vote_average || 0) >= minRating);
        setResults(filtered);
        setTotalPages(data.total_pages);
      } catch (e: any) {
        if (active) setError(e.message || 'Search failed. Please try again.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [query, mediaFilter, genre, year, lang, minRating]);

  const loadMore = async () => {
    if (page >= totalPages) return;
    const next = page + 1;
    setLoading(true);
    try {
      const data = await tmdb.search(query, next);
      let filtered = data.results.filter(
        (m) => m.media_type === 'movie' || m.media_type === 'tv'
      );
      if (mediaFilter !== 'all')
        filtered = filtered.filter((m) => m.media_type === mediaFilter);
      if (genre !== 'all')
        filtered = filtered.filter((m) => matchesGenre(m, genre as number));
      if (year !== 'all')
        filtered = filtered.filter((m) =>
          (m.release_date || m.first_air_date || '').startsWith(year)
        );
      if (lang !== 'all')
        filtered = filtered.filter((m) => m.original_language === lang);
      if (minRating > 0)
        filtered = filtered.filter((m) => (m.vote_average || 0) >= minRating);
      setResults((prev) => [...prev, ...filtered]);
      setPage(next);
    } finally {
      setLoading(false);
    }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) setParams({ q: input.trim() });
  };

  const years = Array.from({ length: 30 }, (_, i) => String(2024 - i));

  /** Check if a media item matches the selected genre, accounting for movie vs TV genre ID differences */
  const matchesGenre = (m: Media, movieGenreId: number): boolean => {
    if (!m.genre_ids) return false;
    const tvGenreId = TV_GENRE_MAP[movieGenreId] ?? movieGenreId;
    return m.genre_ids.includes(movieGenreId) || m.genre_ids.includes(tvGenreId);
  };

  return (
    <div className="min-h-screen bg-zinc-950 pt-20">
      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-8">
        {/* Search bar */}
        <form onSubmit={submit} className="mb-6">
          <div className="flex items-center gap-3 rounded-xl bg-zinc-900 px-4 py-3 ring-1 ring-white/10 focus-within:ring-red-600">
            <SearchIcon className="h-5 w-5 text-zinc-400" />
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Search for movies, web series, people..."
              className="w-full bg-transparent text-base text-white placeholder:text-zinc-500 focus:outline-none"
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowFilters((v) => !v)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                showFilters ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" /> Filters
            </button>
          </div>
        </form>

        {/* Filters panel */}
        {showFilters && (
          <div className="mb-6 rounded-xl bg-zinc-900 p-4 ring-1 ring-white/10">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {/* Type */}
              <div>
                <label className="mb-2 block text-xs font-semibold uppercase text-zinc-400">Type</label>
                <div className="flex gap-1.5">
                  {(['all', 'movie', 'tv'] as MediaType[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => setMediaFilter(t)}
                      className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium capitalize transition ${
                        mediaFilter === t ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                      }`}
                    >
                      {t === 'tv' ? 'Series' : t}
                    </button>
                  ))}
                </div>
              </div>
              {/* Genre */}
              <div>
                <label className="mb-2 block text-xs font-semibold uppercase text-zinc-400">Genre</label>
                <select
                  value={genre === 'all' ? 'all' : String(genre)}
                  onChange={(e) => setGenre(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                  className="w-full rounded-md bg-zinc-800 px-3 py-1.5 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-red-600"
                >
                  <option value="all">All Genres</option>
                  {CATEGORY_GENRES.map((g) => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>
              {/* Year */}
              <div>
                <label className="mb-2 block text-xs font-semibold uppercase text-zinc-400">Year</label>
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  className="w-full rounded-md bg-zinc-800 px-3 py-1.5 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-red-600"
                >
                  <option value="all">All Years</option>
                  {years.map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
              {/* Language */}
              <div>
                <label className="mb-2 block text-xs font-semibold uppercase text-zinc-400">Language</label>
                <select
                  value={lang}
                  onChange={(e) => setLang(e.target.value)}
                  className="w-full rounded-md bg-zinc-800 px-3 py-1.5 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-red-600"
                >
                  <option value="all">All Languages</option>
                  {LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>{l.name}</option>
                  ))}
                </select>
              </div>
            </div>
            {(mediaFilter !== 'all' || genre !== 'all' || year !== 'all' || lang !== 'all') && (
              <button
                onClick={() => {
                  setMediaFilter('all');
                  setGenre('all');
                  setYear('all');
                  setLang('all');
                }}
                className="mt-3 flex items-center gap-1 text-xs text-red-500 hover:text-red-400"
              >
                <X className="h-3 w-3" /> Clear filters
              </button>
            )}
          </div>
        )}

        {/* Results */}
        {!query.trim() ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <SearchIcon className="h-12 w-12 text-zinc-700" />
            <p className="mt-4 text-lg font-semibold text-zinc-400">Search for your favorite movies & series</p>
            <p className="mt-1 text-sm text-zinc-600">Try "Inception", "Breaking Bad", "Squid Game"...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <AlertCircle className="h-10 w-10 text-red-600" />
            <p className="mt-3 text-sm font-semibold text-zinc-400">{error}</p>
          </div>
        ) : loading && results.length === 0 ? (
          <GridSkeleton count={12} />
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <p className="text-lg font-semibold text-zinc-400">No results found for "{query}"</p>
            <p className="mt-1 text-sm text-zinc-600">Try different keywords or remove filters.</p>
          </div>
        ) : (
          <>
            <div className="mb-4">
              <RatingFilter value={minRating} onChange={setMinRating} />
            </div>
            <p className="mb-4 text-sm text-zinc-400">
              Showing results for <span className="font-semibold text-white">"{query}"</span>
            </p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {results.map((m, i) => (
                <MovieCard key={`${m.id}-${i}`} media={m} index={i} fullWidth />
              ))}
            </div>
            {page < totalPages && (
              <div className="mt-8 flex justify-center">
                <button
                  onClick={loadMore}
                  disabled={loading}
                  className="rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700 disabled:opacity-50"
                >
                  {loading ? 'Loading...' : 'Load More'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
