import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertCircle } from 'lucide-react';
import { MovieCard } from '../components/MovieCard';
import { RatingFilter } from '../components/RatingFilter';
import { GridSkeleton } from '../components/Skeleton';
import {
  tmdb,
  CATEGORY_GENRES,
  getGenreId,
  type Media,
} from '../lib/tmdb';

type MediaType = 'movie' | 'tv' | 'both';
type SortBy = 'popularity.desc' | 'vote_average.desc' | 'primary_release_date.desc' | 'first_air_date.desc';

const SORT_OPTIONS = [
  { value: 'popularity.desc', label: 'Popularity' },
  { value: 'vote_average.desc', label: 'Rating' },
  { value: 'primary_release_date.desc', label: 'Year' },
];

export default function Categories() {
  const [params, setParams] = useSearchParams();
  const initialGenre = params.get('genre');
  const initialType = (params.get('type') as MediaType) || 'movie';

  const [selectedGenre, setSelectedGenre] = useState<number | null>(
    initialGenre ? Number(initialGenre) : null
  );
  const [mediaType, setMediaType] = useState<MediaType>(initialType);
  const [sortBy, setSortBy] = useState<SortBy>('popularity.desc');
  const [items, setItems] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [minRating, setMinRating] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);

  // Compute the correct sort key for the active media type
  const getSortKey = (type: 'movie' | 'tv') =>
    type === 'tv' && sortBy === 'primary_release_date.desc'
      ? 'first_air_date.desc'
      : sortBy;

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    setPage(1);
    setItems([]);
    (async () => {
      try {
        // Default genre when none selected
        const baseGenreId = selectedGenre || 28;
        const results: Media[] = [];
        let maxPages = 0;

        if (mediaType === 'movie' || mediaType === 'both') {
          const movieGenreId = getGenreId(baseGenreId, 'movie');
          const movieData = await tmdb.genreMovies(
            movieGenreId,
            1,
            getSortKey('movie')
          );
          if (!active) return;
          const movies = movieData.results
            .filter((m) => m.poster_path)
            .map((m) => ({ ...m, media_type: 'movie' as const }));
          results.push(...movies);
          maxPages = Math.max(maxPages, movieData.total_pages);
        }

        if (mediaType === 'tv' || mediaType === 'both') {
          const tvGenreId = getGenreId(baseGenreId, 'tv');
          const tvData = await tmdb.genreTV(tvGenreId, 1, getSortKey('tv'));
          if (!active) return;
          const shows = tvData.results
            .filter((m) => m.poster_path)
            .map((m) => ({ ...m, media_type: 'tv' as const }));
          results.push(...shows);
          maxPages = Math.max(maxPages, tvData.total_pages);
        }

        if (!active) return;

        // Sort combined results
        const sorted = sortResults(results, sortBy);
        setItems(sorted);
        setTotalPages(maxPages);
      } catch (e: any) {
        if (active) setError(e.message || 'Failed to load titles.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGenre, mediaType, sortBy]);

  const loadMore = async () => {
    const next = page + 1;
    if (next > totalPages) return;
    setLoading(true);
    try {
      const baseGenreId = selectedGenre || 28;
      const results: Media[] = [];

      if (mediaType === 'movie' || mediaType === 'both') {
        const movieGenreId = getGenreId(baseGenreId, 'movie');
        const movieData = await tmdb.genreMovies(
          movieGenreId,
          next,
          getSortKey('movie')
        );
        const movies = movieData.results
          .filter((m) => m.poster_path)
          .map((m) => ({ ...m, media_type: 'movie' as const }));
        results.push(...movies);
      }

      if (mediaType === 'tv' || mediaType === 'both') {
        const tvGenreId = getGenreId(baseGenreId, 'tv');
        const tvData = await tmdb.genreTV(tvGenreId, next, getSortKey('tv'));
        const shows = tvData.results
          .filter((m) => m.poster_path)
          .map((m) => ({ ...m, media_type: 'tv' as const }));
        results.push(...shows);
      }

      const sorted = sortResults(results, sortBy);
      setItems((prev) => [...prev, ...sorted]);
      setPage(next);
    } catch (e: any) {
      setError(e.message || 'Failed to load more titles.');
    } finally {
      setLoading(false);
    }
  };

  const selectGenre = (id: number | null) => {
    setSelectedGenre(id);
    if (id) setParams({ genre: String(id), type: mediaType });
    else setParams({ type: mediaType });
  };

  const switchType = (t: MediaType) => {
    setMediaType(t);
    setParams(selectedGenre ? { genre: String(selectedGenre), type: t } : { type: t });
  };

  const filteredItems = items.filter(
    (m) => minRating === 0 || (m.vote_average || 0) >= minRating
  );

  return (
    <div className="min-h-screen bg-zinc-950 pt-20">
      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-extrabold text-white sm:text-3xl">
            Browse Categories
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Explore by genre, type, and sort order
          </p>
        </div>

        {/* Type toggle — Movies / Web Series / Both */}
        <div className="mb-4 flex gap-2">
          {(
            [
              { value: 'movie', label: 'Movies' },
              { value: 'tv', label: 'Web Series' },
              { value: 'both', label: 'Both' },
            ] as { value: MediaType; label: string }[]
          ).map((t) => (
            <button
              key={t.value}
              onClick={() => switchType(t.value)}
              className={`rounded-full px-5 py-2 text-sm font-bold transition ${
                mediaType === t.value
                  ? 'bg-red-600 text-white'
                  : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Genre grid */}
        <div className="mb-6 grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-9">
          <button
            onClick={() => selectGenre(null)}
            className={`flex flex-col items-center gap-1 rounded-xl p-3 ring-1 transition ${
              selectedGenre === null
                ? 'bg-red-600 text-white ring-red-500'
                : 'bg-zinc-900 text-zinc-300 ring-white/10 hover:bg-zinc-800'
            }`}
          >
            <span className="text-xl">🎬</span>
            <span className="text-[10px] font-semibold sm:text-xs">All</span>
          </button>
          {CATEGORY_GENRES.map((g) => (
            <button
              key={g.id}
              onClick={() => selectGenre(g.id)}
              className={`flex flex-col items-center gap-1 rounded-xl p-3 ring-1 transition ${
                selectedGenre === g.id
                  ? 'bg-red-600 text-white ring-red-500'
                  : 'bg-zinc-900 text-zinc-300 ring-white/10 hover:bg-zinc-800'
              }`}
            >
              <span className="text-xl">{g.icon}</span>
              <span className="text-[10px] font-semibold sm:text-xs">{g.name}</span>
            </button>
          ))}
        </div>

        {/* Sort + Rating filter */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold uppercase text-zinc-500">
              Sort by
            </span>
            <div className="flex gap-1.5">
              {SORT_OPTIONS.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSortBy(s.value as SortBy)}
                  className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                    sortBy === s.value
                      ? 'bg-zinc-700 text-white'
                      : 'bg-zinc-800/60 text-zinc-400 hover:bg-zinc-700'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <RatingFilter value={minRating} onChange={setMinRating} />
        </div>

        {/* Results */}
        {loading && items.length === 0 ? (
          <GridSkeleton count={18} />
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <AlertCircle className="h-10 w-10 text-red-600" />
            <p className="mt-3 text-sm font-semibold text-zinc-400">{error}</p>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-lg font-semibold text-zinc-400">No titles found</p>
            <p className="mt-1 text-sm text-zinc-600">
              Try a different genre or adjust your filters.
            </p>
          </div>
        ) : (
          <>
            <p className="mb-4 text-sm text-zinc-500">
              {filteredItems.length} title{filteredItems.length !== 1 ? 's' : ''} found
            </p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {filteredItems.map((m, i) => (
                <MovieCard key={`${m.id}-${i}`} media={m} index={i} fullWidth />
              ))}
            </div>
            {page < totalPages && (
              <div className="mt-8 flex justify-center">
                <button
                  onClick={loadMore}
                  disabled={loading}
                  className="rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700 disabled:opacity-50"
                >
                  {loading ? 'Loading...' : 'Load More'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

/** Sort an array of mixed movie/tv results by the given sort key */
function sortResults(items: Media[], sortBy: SortBy): Media[] {
  const arr = [...items];
  switch (sortBy) {
    case 'vote_average.desc':
      return arr.sort((a, b) => (b.vote_average || 0) - (a.vote_average || 0));
    case 'primary_release_date.desc':
    case 'first_air_date.desc':
      return arr.sort((a, b) => {
        const da = new Date(a.release_date || a.first_air_date || '1970').getTime();
        const db = new Date(b.release_date || b.first_air_date || '1970').getTime();
        return db - da;
      });
    default:
      return arr.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
  }
}
