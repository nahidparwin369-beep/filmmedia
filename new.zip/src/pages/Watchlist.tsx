import { Link } from 'react-router-dom';
import { Bookmark, Trash2, Film } from 'lucide-react';
import { useWatchlist } from '../lib/watchlist';
import { img, getTitle, getYear, getMediaType } from '../lib/tmdb';

export default function Watchlist() {
  const { items, remove, clear } = useWatchlist();

  return (
    <div className="min-h-screen bg-zinc-950 pt-20">
      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-8">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-extrabold text-white sm:text-3xl">
              <Bookmark className="h-6 w-6 text-red-600" /> My Watchlist
            </h1>
            <p className="mt-1 text-sm text-zinc-400">
              {items.length} title{items.length !== 1 ? 's' : ''} saved
            </p>
          </div>
          {items.length > 0 && (
            <button
              onClick={() => {
                if (confirm('Remove all titles from your watchlist?')) clear();
              }}
              className="flex items-center gap-1.5 rounded-full bg-zinc-800 px-4 py-2 text-xs font-medium text-zinc-300 ring-1 ring-white/10 transition hover:bg-red-600 hover:text-white"
            >
              <Trash2 className="h-3.5 w-3.5" /> Clear All
            </button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full bg-zinc-900">
              <Film className="h-10 w-10 text-zinc-700" />
            </div>
            <p className="mt-4 text-lg font-semibold text-zinc-400">Your watchlist is empty</p>
            <p className="mt-1 text-sm text-zinc-600">Add movies & series by tapping the + button</p>
            <Link
              to="/"
              className="mt-6 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
            >
              Browse Titles
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {items.map((m) => {
              const type = getMediaType(m);
              return (
                <div key={m.id} className="group relative">
                  <Link to={`/${type}/${m.id}`} className="block">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-lg bg-zinc-800 shadow-lg">
                      {m.poster_path ? (
                        <img
                          src={img(m.poster_path, 'w342')}
                          alt={getTitle(m)}
                          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.parentElement?.classList.add('flex', 'items-center', 'justify-center');
                          }}
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center gap-2 p-2 text-center">
                          <Film className="h-8 w-8 text-zinc-600" />
                          <span className="text-xs text-zinc-500 line-clamp-3">{getTitle(m)}</span>
                        </div>
                      )}
                      <div className="absolute top-1.5 right-1.5 rounded bg-red-600/90 px-1.5 py-0.5 text-[9px] font-bold uppercase text-white">
                        {type === 'tv' ? 'Series' : 'Movie'}
                      </div>
                    </div>
                    <h3 className="mt-1.5 truncate text-xs font-medium text-zinc-200 group-hover:text-white">
                      {getTitle(m)}
                    </h3>
                    <p className="text-[10px] text-zinc-500">{getYear(m)}</p>
                  </Link>
                  <button
                    onClick={() => remove(m.id)}
                    className="absolute right-1.5 bottom-9 grid h-7 w-7 place-items-center rounded-full bg-black/70 text-white opacity-0 backdrop-blur transition hover:bg-red-600 group-hover:opacity-100"
                    title="Remove"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

