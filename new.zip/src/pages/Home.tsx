import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { SearchHero } from '../components/SearchHero';
import { HeroBanner } from '../components/HeroBanner';
import { Row } from '../components/Row';
import { Top10Row } from '../components/Top10Row';
import { HeroSkeleton, CardSkeleton } from '../components/Skeleton';
import { tmdb, CATEGORY_GENRES, type Media } from '../lib/tmdb';

export default function Home() {
  const [trending, setTrending] = useState<Media[]>([]);
  const [topRated, setTopRated] = useState<Media[]>([]);
  const [popularTV, setPopularTV] = useState<Media[]>([]);
  const [nowPlaying, setNowPlaying] = useState<Media[]>([]);
  const [upcoming, setUpcoming] = useState<Media[]>([]);
  const [top10, setTop10] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [t, tr, ptv, np, up, pop] = await Promise.all([
        tmdb.trending(),
        tmdb.topRatedMovies(),
        tmdb.popularTV(),
        tmdb.nowPlaying(),
        tmdb.upcoming(),
        tmdb.popularMovies(),
      ]);
      setTrending(t.results);
      setTopRated(tr.results);
      setPopularTV(ptv.results);
      setNowPlaying(np.results);
      setUpcoming(up.results);
      setTop10(pop.results);
    } catch (e: any) {
      setError(e.message || 'Failed to load content. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const quickFilters = [
    { label: 'Trending', to: '/search?q=trending' },
    ...CATEGORY_GENRES.slice(0, 6).map((g) => ({
      label: g.name,
      to: `/categories?genre=${g.id}`,
    })),
  ];

  if (error && !loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-950 px-4 pt-14 text-center">
        <AlertCircle className="h-12 w-12 text-red-600" />
        <p className="mt-4 text-lg font-semibold text-white">{error}</p>
        <p className="mt-1 text-sm text-zinc-500">
          Make sure your internet connection is working.
        </p>
        <button
          onClick={load}
          className="mt-4 flex items-center gap-2 rounded-full bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-red-700"
        >
          <RefreshCw className="h-4 w-4" /> Retry
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950">
      {loading ? (
        <>
          <HeroSkeleton />
          <div className="mt-8 space-y-6">
            <div className="flex gap-3 overflow-hidden px-4 sm:px-8">
              {Array.from({ length: 8 }).map((_, i) => <CardSkeleton key={i} />)}
            </div>
            <div className="flex gap-3 overflow-hidden px-4 sm:px-8">
              {Array.from({ length: 8 }).map((_, i) => <CardSkeleton key={i} />)}
            </div>
            <div className="flex gap-3 overflow-hidden px-4 sm:px-8">
              {Array.from({ length: 8 }).map((_, i) => <CardSkeleton key={i} />)}
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Search Hero Section — at the very top */}
          <SearchHero trending={trending} />

          {/* Trending hero banner */}
          <HeroBanner items={trending} />

          {/* Quick filter buttons */}
          <div className="sticky top-[57px] z-20 border-y border-white/5 bg-zinc-950/95 backdrop-blur">
            <div
              className="flex gap-2 overflow-x-auto px-4 py-3 sm:px-8 scrollbar-none"
              style={{ scrollbarWidth: 'none' }}
            >
              {quickFilters.map((f) => (
                <Link
                  key={f.label}
                  to={f.to}
                  className="flex-shrink-0 rounded-full bg-zinc-800 px-4 py-1.5 text-xs font-medium text-zinc-300 ring-1 ring-white/10 transition hover:bg-red-600 hover:text-white"
                >
                  {f.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="space-y-2 py-4">
            <Row title="Trending Now" accent="🔥" items={trending} />
            <Top10Row title="Top 10 in India Today" accent="🏆" items={top10} />
            <Row title="Top Rated Movies" accent="⭐" items={topRated} />
            <Row title="Popular Web Series" accent="📺" items={popularTV} />
            <Row title="New Releases" accent="🎬" items={nowPlaying} />
            <Row title="Coming Soon" accent="🎟️" items={upcoming} />
          </div>
        </>
      )}
    </div>
  );
}
